const axios = require("axios");
const {
  addCallLogsQuery,
  updateCallLogsQuery,
  isCallEndedQuery,
  getCallLogsQuery,
  getLatestCallLogsQuery,
  setCallDurationQuery,
  totalCountOfCallLogs,
  getCallsPerDateQueryForEmployee,
  getCallsPerDateQueryForAdmin,
  getCallLogAndCountQuery,
  getCustomerCallLogsQuery,
  updateOnCallStatusQuery,
  updateCallNoteQuery,
} = require("../Services/dbQueries");
const db = require("../../database/mySqlConnection").promise();
const {
  findCustomerByNumber,
  createCustomer,
} = require("../Services/customer");
const { fetchCustomerLead } = require("../Services/lead");
const log = require("../../logger");

const getCustomerIdForLogs = async (requestData) => {
  try {
    const { phoneNo, userId, name } = requestData;

    let customerId;
    let customer;

    customer = await findCustomer(phoneNo);
    if (!customer.status) {
      let customer = await getUserData(91, phoneNo, userId);

      if (!customer.status) {
        customer = await createCustomer(requestData);

        if (customer.status != 200) {
          return res.badRequest({ message: result.data });
        }
        customerId = customer.customerId;
      } else {
        customerId = customer.customerId;
      }
    } else {
      customerId = customer.customerId;
    }

    return {
      status: 200,
      customerId: customerId,
    };
  } catch (error) {
    throw new Error(error.message);
  }
};

const findCustomer = async (phoneNo) => {
  const response = await findCustomerByNumber(phoneNo);
  if (response.data) {
    let customerId = response.data[0].id;
    return {
      status: true,
      customerId: customerId,
      message: "Customer is available in contacts",
    };
  }
  return {
    status: false,
    customerId: null,
    message: "Customer is not available in contacts",
  };
};

const getUserData = async (countryCode, phoneNo, userId) => {
  try {
    const response = await getUserDataFromMeriDariyDB(countryCode, phoneNo);

    if (response.status) {
      const userData = { ...response.data.userData, userId };

      const result = await createCustomer(userData);

      if (result.status == 200) {
        return {
          status: true,
          customerId: result.customerId,
        };
      }
    }

    return {
      status: false,
      customerId: null,
    };
  } catch (error) {
    console.log(error);
    throw new Error(error.message);
  }
};

const getUserDataFromMeriDariyDB = async (countryCode = 91, phoneNo) => {
  try {
    const apiUrl = `https://meridairy.in/software/api/admin/getUserDetailsForCrm`;
    const token = "CRM1234TESTING";
    const response = await axios.get(
      `${apiUrl}?country_code=${countryCode}&mobile=${phoneNo}&token=${token}`
    );
    return response.data;
  } catch (error) {
    throw new Error(error.message);
  }
};

const getCallerData = async (phoneNo, numberOfLatestRecords) => {
  try {
    const response = await findCustomer(phoneNo);

    let customerId;
    let callLogDetails = null;
    let customerLead = null;
    if (response.status) {
      customerId = response.customerId;

      if (customerId) {
        const res = await getLatestCallLogs(phoneNo, numberOfLatestRecords);
        callLogDetails = res.data;
        if (callLogDetails?.length == 1 && callLogDetails[0].id == null) {
          callLogDetails = null;
        }

        const leadResponse = await fetchCustomerLead(customerId);

        customerLead = leadResponse.data ?? null;
      } else {
        callLogDetails = null;
      }
    }

    const dairyResponse = await getUserDataFromMeriDariyDB(null, phoneNo);

    const orderData = dairyResponse.data?.orderData ?? null;
    if (orderData || callLogDetails || customerLead) {
      return {
        status: 200,
        data: {
          callLogDetails: callLogDetails,
          orderData: orderData,
          customerLead: customerLead,
        },
      };
    }

    // If no records found in both DB's then send a message to the user
    return {
      status: 409,
      data: "No data available",
    };
  } catch (error) {
    throw new Error(error.message);
  }
};

const getLatestCallLogs = async (phoneNo, numberOfLatestRecords) => {
  try {
    const [result] = await db.execute(getLatestCallLogsQuery, [
      phoneNo,
      0,
      numberOfLatestRecords,
    ]);

    if (result.length === 0) {
      return {
        status: 409,
        data: null,
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const addCallLog = async (inputData) => {
  try {
    const [result] = await db.execute(addCallLogsQuery, [
      inputData.customerId,
      inputData.employeeId,
      inputData.callingStatusId,
      inputData.callDate,
    ]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: { callLogId: result.insertId },
      };
    } else {
      return {
        status: 400,
        data: "Data Insertion Failed",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const updateCallLog = async (inputData) => {
  try {
    const { sqlQuery, queryParams } = updateCallLogsQuery(inputData);

    const [result] = await db.execute(sqlQuery, queryParams);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Data Insertion Failed",
      };
    }
  } catch (error) {
    log.error({
      message: error,
      FunctionName: "updateCall",
      FileName: "callLogController",
    });
    throw new Error(error.message);
  }
};

const setCallDuration = async (inputData) => {
  try {
    const { sqlQuery, queryParams } = setCallDurationQuery(inputData);

    const [result] = await db.execute(sqlQuery, queryParams);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Data Insertion Failed",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const checkCallStatus = async (inputData) => {
  try {
    const [result] = await db.execute(isCallEndedQuery, [inputData.callLogId]);
    const callStatus = result[0].on_call;
    if (callStatus === 0) {
      return { status: false, data: "Call is already ended" };
    }
    return { status: true, data: "Call is ongoing" };
  } catch (error) {
    throw new Error(error.message);
  }
};

const getCallLogData = async (filter, User, pageNo) => {
  try {
    const { sqlQuery, queryParams } = getCallLogsQuery(filter, User, pageNo);

    const [result] = await db.execute(sqlQuery, queryParams);

    const dataPerPage = process.env.call_logs_data_per_page;

    const totalRows = result.length > 0 ? result[0].totalRows : 0;
    const totalPages = Math.ceil(totalRows / dataPerPage);

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      if (pageNo) {
        return {
          status: 200,
          data: {
            callLogData: result,
            totalPages: totalPages,
            dataPerPage: dataPerPage,
          },
        };
      }

      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getCallLogWithCount = async ({ isAdmin, userId }) => {
  try {
    const [result] = await db.execute(getCallLogAndCountQuery, [userId]);

    if (result.length === 0) {
      return {
        status: 409,
        data: null,
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getCustomerLogs = async (phoneNo) => {
  try {
    const [result] = await db.execute(getCustomerCallLogsQuery, [phoneNo]);

    if (result.length === 0) {
      return {
        status: 409,
        data: null,
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const updateOnCallStatus = async (callLogId) => {
  try {
    const [result] = await db.execute(updateOnCallStatusQuery, [1, callLogId]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Data Updation Failed",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const setCallNote = async (data) => {
  try {
    const [result] = await db.execute(updateCallNoteQuery, [
      data.note,
      data.callLogId,
    ]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Data Updation Failed",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const retrieveCallCountsByDay = async (User) => {
  try {
    let queryResult;
    if (User.isAdmin) {
      [queryResult] = await db.execute(getCallsPerDateQueryForAdmin);
    } else {
      [queryResult] = await db.execute(getCallsPerDateQueryForEmployee, [
        User.userId,
      ]);
    }

    if (queryResult.length === 0) {
      return {
        status: 400,
        data: "Error occurred during querying the database",
      };
    }

    // Function to convert UTC date to Indian Standard Time (IST)
    const convertUTCtoIST = (utcDate) => {
      const date = new Date(utcDate);
      // Adjust for Indian Standard Time (IST) offset (+5 hours and 30 minutes)
      date.setHours(date.getHours() + 5);
      date.setMinutes(date.getMinutes() + 30);
      return date;
    };

    // Get the current year and month
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth() + 1;

    // Create an array of dates for the current month
    const datesArray = Array.from(
      { length: new Date(year, month, 0).getDate() },
      (_, i) => i + 1
    );

    // Create an object to store call counts for each date
    const callCounts = queryResult.reduce((acc, { callDate, callCount }) => {
      // Convert UTC callDate to Indian Standard Time (IST)
      const istDate = convertUTCtoIST(callDate);
      // Extract the date part (day) from IST date
      const date = istDate.getDate();
      acc[date] = callCount;
      return acc;
    }, {});

    // Create an array of call counts for each date
    const callCountArray = datesArray.map((date) => callCounts[date] ?? 0);

    return {
      status: 200,
      data: { datesArray: datesArray, callCountArray: callCountArray },
    };
  } catch (error) {
    throw new Error(error.message);
  }
};

module.exports = {
  findCustomer,
  getUserData,
  addCallLog,
  getCustomerIdForLogs,
  updateCallLog,
  checkCallStatus,
  getCallLogData,
  getCallerData,
  setCallDuration,
  getCallLogWithCount,
  getCustomerLogs,
  updateOnCallStatus,
  retrieveCallCountsByDay,
  setCallNote,
};
