const {
  searchEmployeeByNumberQuery,
  searchEmployeeByEmailQuery,
  createEmployeeQuery,
  getAllEmployeeQuery,
  searchEmployeeQuery,
  totalCountOfEmployee,
  deleteEmployeeQuery,
  getEmployeeByIdQuery,
  updateEmployeeQuery,
  changeEmployeeStatusQuery,
  getEmployeeListQuery,
} = require("../Services/dbQueries");
const db = require("../../database/mySqlConnection").promise();

const createEmployee = async (inputData) => {
  try {
    if (inputData.phoneNo) {
      const phoneNumber = inputData.phoneNo;
      let response = await findEmployeeByMobile(phoneNumber);

      if (response.length >= 1) {
        return {
          status: 400,
          data: response.message,
        };
      }
    }
    if (inputData.email) {
      const email = inputData.email;
      let response = await findEmployeeByEmail(email);

      if (response.length >= 1) {
        return {
          status: 400,
          data: response.message,
        };
      }
    }

    const [result] = await db.execute(createEmployeeQuery, [
      inputData.name || null,
      inputData.email || null,
      inputData.phoneNo || null,
      inputData.address || null,
      inputData.countryId || null,
      inputData.stateId || null,
      inputData.cityId || null,
      inputData.image || null,
      2,
      inputData.status || null,
      1,
      inputData.password || null,
    ]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Data Insertion Failed",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const findEmployeeByMobile = async (phoneNo) => {
  try {
    let [result] = await db.execute(searchEmployeeByNumberQuery, [phoneNo]);

    const dataLength = result.length;

    if (dataLength == 0) {
      return {
        status: 200,
        length: dataLength,
        data: null,
        message: "Phone number does not exist",
      };
    } else {
      return {
        status: 200,
        length: dataLength,
        data: result,
        message: "Phone number already exist",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};
const findEmployeeByEmail = async (email) => {
  try {
    let [result] = await db.execute(searchEmployeeByEmailQuery, [email]);

    const dataLength = result.length;

    if (dataLength == 0) {
      return {
        status: 200,
        length: dataLength,
        data: null,
        message: "Email does not exist",
      };
    } else {
      return {
        status: 200,
        length: dataLength,
        data: result,
        message: "Email already exist",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getEmployeeList = async (page) => {
  try {
    let dataPerPage;
    let offset;

    if (page) {
      dataPerPage = process.env.employee_data_per_page;
      offset = (page - 1) * dataPerPage;
    } else {
      dataPerPage = 18446744073709551615;
      offset = 0;
    }

    const [countResult] = await db.execute(totalCountOfEmployee);
    const totalRows = countResult[0].totalRows;

    const totalPages = Math.ceil(totalRows / dataPerPage);

    const [result] = await db.execute(getAllEmployeeQuery, [
      dataPerPage,
      offset,
    ]);

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      if (page) {
        return {
          status: 200,
          data: {
            employeeList: result,
            totalPages: totalPages,
            dataPerPage: dataPerPage,
            totalRows:totalRows
          },
        };
      } else {
        return {
          status: 200,
          data: result,
        };
      }
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const deleteEmployeeFromDb = async (employeeId) => {
  try {
    const [result] = await db.execute(deleteEmployeeQuery, [employeeId]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getEmployeeFromDb = async (employeeId) => {
  try {
    const [result] = await db.execute(getEmployeeByIdQuery, [employeeId]);

    if (result.length === 0) {
      return {
        status: 400,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const updateEmployeeInDb = async (updatedData) => {
  try {
    if (updatedData.phoneNo) {
      const phoneNumber = updatedData.phoneNo;
      let response = await findEmployeeByMobile(phoneNumber);

      if (response.length >= 1 && updatedData.id != response.data[0].id) {
        return {
          status: 400,
          data: response.message,
        };
      }
    }
    if (updatedData.email) {
      const email = updatedData.email;
      let response = await findEmployeeByEmail(email);

      if (response.length >= 1 && updatedData.id != response.data[0].id) {
        return {
          status: 400,
          data: response.message,
        };
      }
    }
  
    const [result] = await db.execute(updateEmployeeQuery, [
      updatedData.name || null,
      updatedData.email || null,
      updatedData.phoneNo || null,
      updatedData.address || null,
      updatedData.countryId || null,
      updatedData.stateId || null,
      updatedData.cityId || null,
      updatedData.image || null,
      updatedData.image || null,
      updatedData.password || null,
      updatedData.password || null,
      updatedData.id || null,
    ]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const updateEmployeeStatus = async (employeeId) => {
  try {
    const [updateResult] = await db.execute(changeEmployeeStatusQuery, [
      employeeId,
    ]);

    if (updateResult.affectedRows === 1) {
      return {
        status: 200,
        data: updateResult,
      };
    } else {
      return {
        status: 400,
        data: "Some error occurred during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getAllEmployees = async () => {
  try {
    const [result] = await db.execute(getEmployeeListQuery);

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const searchEmployeeFromDb = async (search) => {
  try {
    search = `%${search}%`;
    let result;

    [result] = await db.execute(searchEmployeeQuery, [search, search, search]);

    if (result.length > 0) {
      return {
        status: 200,
        data: result,
      };
    }

    // If nothing is found, return an error
    return {
      status: 400,
      data: "No data found",
    };
  } catch (error) {
    throw new Error(error.message);
  }
};

module.exports = {
  createEmployee,
  getEmployeeList,
  deleteEmployeeFromDb,
  getEmployeeFromDb,
  updateEmployeeInDb,
  updateEmployeeStatus,
  getAllEmployees,
  searchEmployeeFromDb,
};
