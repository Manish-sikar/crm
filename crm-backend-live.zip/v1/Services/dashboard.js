const {
  getTotalCallForAdminQuery,
  getTotalCallForUserQuery,
  getReceivedCallForAdminQuery,
  getReceivedCallForUserQuery,
  getMissedCallForAdminQuery,
  getMissedCallForUserQuery,
  avgCallDurationForAdminQuery,
  avgCallDurationForUserQuery,
  lastActiveEmployeeQuery
} = require("../Services/dbQueries");
const db = require("../../database/mySqlConnection").promise();

const totalCall = async (isAdmin, userId) => {
  try {
    let result;
    if (isAdmin) {
      [result] = await db.execute(getTotalCallForAdminQuery);
    } else {
      [result] = await db.execute(getTotalCallForUserQuery, [userId]);
    }

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const receivedCall = async (isAdmin, userId) => {
  try {
    let result;
    if (isAdmin) {
      [result] = await db.execute(getReceivedCallForAdminQuery, [1]);
    } else {
      [result] = await db.execute(getReceivedCallForUserQuery, [1, userId]);
    }

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const missedCall = async (isAdmin, userId) => {
  try {
    let result;
    if (isAdmin) {
      [result] = await db.execute(getMissedCallForAdminQuery, [2]);
    } else {
      [result] = await db.execute(getMissedCallForUserQuery, [2, userId]);
    }

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};
const avgCallDuration = async (isAdmin, userId) => {
  try {
    let result;
    if (isAdmin) {
      [result] = await db.execute(avgCallDurationForAdminQuery);
    } else {
      [result] = await db.execute(avgCallDurationForUserQuery, [userId]);
    }

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      const averageDurationInSeconds = result[0].averageDurationInSeconds || 0;

      const averageFormatted = new Date(averageDurationInSeconds * 1000)
        .toISOString()
        .slice(11, 19);

      return {
        status: 200,
        data: averageFormatted,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const lastActiveEmployee = async () => {
  try {
    const [result] = await db.execute(lastActiveEmployeeQuery);

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

module.exports = {
  totalCall,
  receivedCall,
  missedCall,
  avgCallDuration,
  lastActiveEmployee,
};
