const {
  createQuotationQuery,
  addQuoteRelationQuery,
  getQuotationDetailByIdQuery,
  getQuotationDetailByLeadQuery
} = require("../Services/dbQueries");
const { randomNumber } = require("./common");
const { getAdminDetails } = require("./auth");
// const puppeteer = require("puppeteer");
const fs = require("fs");
const handlebars = require("handlebars");
const path = require("path");
const moment = require("moment");
const db = require("../../database/mySqlConnection").promise();

const createQuotation = async (inputData) => {
  try {
    const [result] = await db.execute(createQuotationQuery, [
      inputData.userId,
      inputData.customerId,
      inputData.leadId,
      inputData.totalAmount,
      inputData.note,
      inputData.gst,
      inputData.quoteDate,
      inputData.quoteDueDate,
    ]);
    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Data Insertion Failed",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const addQuoteRelation = async (quotedProductArray, quoteId) => {
  try {
    // Initialize an array to store the results of each insert operation
    const insertResults = [];

    // Loop through the quotedProductArray
    for (const product of quotedProductArray) {
      const [result] = await db.execute(addQuoteRelationQuery, [
        product.productId,
        quoteId,
        product.price,
        product.customPrice,
        product.quantity,
      ]);

      insertResults.push(result);
    }

    // Check the results of all insert operations
    const successfulInserts = insertResults.filter(
      (result) => result.affectedRows === 1
    );

    if (successfulInserts.length === quotedProductArray.length) {
      // All inserts were successful
      return { status: 200, data: "Product quoted successfully" };
    } else {
      // Some inserts failed
      return {
        status: 400,
        data: "Some error occurred during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getQuotationDetailById = async (quotationId) => {
  try {
    const { data: adminDetails } = await getAdminDetails();

    const [result] = await db.execute(getQuotationDetailByIdQuery, [
      quotationId,
    ]);

    if (result.length >= 1) {
      return {
        status: 200,
        data: { admin: adminDetails, quoteDetail: result },
      };
    } else {
      return {
        status: 400,
        data: "Data Insertion Failed",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getQuotationDetailByLead = async (quotationId) => {
  try {
    const [result] = await db.execute(getQuotationDetailByLeadQuery, [
      quotationId,
    ]);

    if (result.length >= 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 201,
        data: null,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const createQuotationPdf = async (quoteData) => {
  // try {
  
  //   const browser = await puppeteer.launch({ headless: "new" });
  //   const page = await browser.newPage();

  //   // Resolve the path to the file 'quotation-template.hbs' relative to the current directory
  //   const filePath = path.resolve(
  //     constants.PDF_DIR_PATH_V1,
  //     "quotation-template.hbs"
  //   );

  //   // Read the Handlebars template file
  //   const templateHtml = fs.readFileSync(filePath, "utf8");

  //   handlebars.registerHelper("formatDate", function (date) {
  //     // Use Moment.js to format the date
  //     return moment(date).format("D-MMM-YYYY");
  //   });

  //   handlebars.registerHelper("jsonParse", function (jsonString) {
  //     return JSON.parse(jsonString);
  //   });

  //   handlebars.registerHelper('addOne', function(index) {
  //     // Add 1 to the index value
  //     return index + 1;
  //   });

  //   // Compile the Handlebars template
  //   const template = handlebars.compile(templateHtml);

  //   // Render the template with the dynamic data
  //   const html = template(quoteData);

  //   // Set content and convert to PDF
  //   await page.setContent(html, { waitUntil: "networkidle0" });

  //   // Generate PDF buffer instead of saving it to a file
  //   const pdfBuffer = await page.pdf({ format: "A4" });

  //   console.log("PDF generated successfully.");

  //   await browser.close();

  //   // Return the PDF buffer
  //   // return pdfBuffer;
  //   return {
  //     status: 200,
  //     pdf: pdfBuffer,
  //   };
  // } catch (error) {
  //   console.error(error);
  //   return {
  //     status: 400,
  //     data: error.message,
  //   };
  // }
};

module.exports = {
  createQuotation,
  addQuoteRelation,
  createQuotationPdf,
  getQuotationDetailById,
  getQuotationDetailByLead,
};
