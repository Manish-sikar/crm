const {
  createSubCategoryQuery,
  searchSubCategoryTableQuery,
  getAllSubCategoryQuery,
  totalCountOfSubCategory,
  deleteSubCategoryQuery,
  getSubCategoryByIdQuery,
  updateSubCategoryQuery,
  getSubCategoryOfCategoryIdQuery
} = require("../Services/dbQueries");
const db = require("../../database/mySqlConnection").promise();

const createSubCategory = async (inputData) => {
  try {
    if (inputData.name) {
      const categoryName = inputData.name;
      let response = await searchSubCategoryTable(categoryName);

      if (response.length >= 1) {
        return {
          status: 400,
          data: "Sub Category already exist",
        };
      }
    }

    const [result] = await db.execute(createSubCategoryQuery, [
      inputData.name,
      inputData.categoryId ?? null,
      inputData.status,
    ]);
    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Data Insertion Failed",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const searchSubCategoryTable = async (categoryName) => {
  try {
    let [result] = await db.execute(searchSubCategoryTableQuery, [
      categoryName,
    ]);

    const dataLength = result.length;

    if (dataLength == 0) {
      return {
        status: 200,
        length: dataLength,
        data: null,
        message: "Sub Category not found",
      };
    } else {
      return {
        status: 200,
        length: dataLength,
        data: result,
        message: "Sub Category found successfully",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getAllSubCategory = async (page) => {
  try {
    let dataPerPage;
    let offset;

    if (page) {
      dataPerPage = process.env.sub_category_data_per_page;
      offset = (page - 1) * dataPerPage;
    } else {
      dataPerPage = 18446744073709551615;
      offset = 0;
    }

    const [countResult] = await db.execute(totalCountOfSubCategory);
    const totalRows = countResult[0].totalRows;

    const totalPages = Math.ceil(totalRows / dataPerPage);

    const [result] = await db.execute(getAllSubCategoryQuery, [
      dataPerPage,
      offset,
    ]);

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      if (page) {
        return {
          status: 200,
          data: {
            subCategoryList: result,
            totalPages: totalPages,
            dataPerPage: dataPerPage,
            totalRows: totalRows,
          },
        };
      } else {
        return {
          status: 200,
          data: result,
        };
      }
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const deleteSubCategoryFromDb = async (subCategoryId) => {
  try {
    const [result] = await db.execute(deleteSubCategoryQuery, [subCategoryId]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const updateSubCategoryInDb = async (
  subCategoryName,
  subCategoryId,
  categoryId
) => {
  try {
    if (subCategoryName) {
      let response = await searchSubCategoryTable(subCategoryName);
      console.log(response);

      if ((response.length = 1 && response.data[0].id != subCategoryId)) {
        return {
          status: 400,
          data: "Sub Category already exist",
        };
      }
    }

    const [result] = await db.execute(updateSubCategoryQuery, [
      subCategoryName,
      categoryId,
      subCategoryId,
    ]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getSubCategoryFromDb = async (subCategoryId) => {
  try {
    const [result] = await db.execute(getSubCategoryByIdQuery, [subCategoryId]);

    if (result.length === 0) {
      return {
        status: 400,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getSubCategoryOfCategory = async (categoryId) => {
  try {
    const [result] = await db.execute(getSubCategoryOfCategoryIdQuery, [categoryId]);
   

    if (result.length === 0) {
      return {
        status: 400,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

module.exports = {
  createSubCategory,
  getAllSubCategory,
  deleteSubCategoryFromDb,
  updateSubCategoryInDb,
  getSubCategoryFromDb,
  getSubCategoryOfCategory
};
