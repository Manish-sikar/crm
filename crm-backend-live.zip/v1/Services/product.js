const {
  createProductQuery,
  searchProductQuery,
  getAllProductQuery,
  deleteProductQuery,
  getProductByIdQuery,
  getProductByNameQuery,
  updateReasonQuery,
  totalCountOfProduct,
  getFilterProductQuery,
  addProductRelationQuery,
  selectLeadQuery,
  replaceLeadProductQuery,
  updateLeadProductQuery,
} = require("../Services/dbQueries");
const db = require("../../database/mySqlConnection").promise();

const addNewProduct = async (inputData) => {
  try {
    if (inputData.name) {
      const productName = inputData.name;
      let response = await searchProductTable(productName);

      if (response.length >= 1) {
        return {
          status: 400,
          data: "Product already exist",
        };
      }
    }

    const [result] = await db.execute(createProductQuery, [
      inputData.name,
      inputData.price ?? null,
      inputData.description ?? null,
      inputData.categoryId ?? null,
      inputData.subCategoryId ?? null,
      inputData.status ?? 1,
    ]);
    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Data Insertion Failed",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const searchProductTable = async (productName) => {
  try {
    let [result] = await db.execute(searchProductQuery, [productName]);

    const dataLength = result.length;

    if (dataLength == 0) {
      return {
        status: 200,
        length: dataLength,
        data: null,
        message: "Product not found",
      };
    } else {
      return {
        status: 200,
        length: dataLength,
        data: result,
        message: "Product found successfully",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getAllProduct = async (page) => {
  try {
    let dataPerPage;
    let offset;

    if (page) {
      dataPerPage = process.env.product_data_per_page;
      offset = (page - 1) * dataPerPage;
    } else {
      dataPerPage = 18446744073709551615;
      offset = 0;
    }

    const [countResult] = await db.execute(totalCountOfProduct);
    const totalRows = countResult[0].totalRows;

    const totalPages = Math.ceil(totalRows / dataPerPage);

    const [result] = await db.execute(getAllProductQuery, [
      dataPerPage,
      offset,
    ]);

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      if (page) {
        return {
          status: 200,
          data: {
            productList: result,
            totalPages: totalPages,
            dataPerPage: dataPerPage,
            totalRows: totalRows,
          },
        };
      } else {
        return {
          status: 200,
          data: result,
        };
      }
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const deleteProductFromDb = async (productId) => {
  try {
    const [result] = await db.execute(deleteProductQuery, [productId]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getFilterProductList = async (categoryId, subCategoryId) => {
  try {
    const [result] = await db.execute(getFilterProductQuery, [
      categoryId,
      subCategoryId,
    ]);

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const addProductRelation = async (productArray, leadId) => {
  try {
    // Initialize an array to store the results of each insert operation
    const insertResults = [];

    // Loop through the productArray
    for (const productId of productArray) {
      const [result] = await db.execute(addProductRelationQuery, [
        leadId,
        productId,
      ]);

      insertResults.push(result);
    }

    // Check the results of all insert operations
    const successfulInserts = insertResults.filter(
      (result) => result.affectedRows === 1
    );

    if (successfulInserts.length === productArray.length) {
      // All inserts were successful
      return { status: 200, data: "Product added successfully" };
    } else {
      // Some inserts failed
      return {
        status: 400,
        data: "Some error occurred during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const updateProductIdsForLead = async (leadId, currentProductIds) => {
  try {
    // Retrieve previous product IDs for the lead ID
    const [results, fields] = await db.execute(selectLeadQuery, [leadId]);
    const previousProductIds = results.map((row) => row.productId);

    // Identify removed product IDs
    const removedProductIds = previousProductIds.filter(
      (productId) => !currentProductIds.includes(productId)
    );

    // Handle removed product IDs
    for (const productId of removedProductIds) {
      await db.execute(updateLeadProductQuery, [leadId, productId]);
    }

    // Identify new product IDs
    const newProductIds = currentProductIds.filter(
      (productId) => !previousProductIds.includes(productId)
    );

    // Insert new product IDs
    for (const productId of newProductIds) {
      await db.execute(replaceLeadProductQuery, [leadId, productId]);
    }

    return { status: 200, data: "Product updates applied successfully" };
  } catch (error) {
    console.error("Error:", error);
    return { status: 400, data: error };
  }
};

const getProductFromDb = async (productId) => {
  try {
    const [result] = await db.execute(getProductByIdQuery, [productId]);

    if (result.length === 0) {
      return {
        status: 400,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getProductDetailsFromName = async (productName) => {
  try {
    const [result] = await db.execute(getProductByNameQuery, [productName]);

    if (result.length === 0) {
      return {
        status: 400,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};



module.exports = {
  addNewProduct,
  getAllProduct,
  deleteProductFromDb,
  getFilterProductList,
  addProductRelation,
  updateProductIdsForLead,
  getProductFromDb,
  getProductDetailsFromName
};
