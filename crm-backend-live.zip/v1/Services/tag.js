const {
  createTagQuery,
  searchTagQuery,
  getAllTagQuery,
  deleteTagQuery,
  getTagByIdQuery,
  updateTagQuery,
  totalCountOfTag,
} = require("../Services/dbQueries");
const db = require("../../database/mySqlConnection").promise();

const addNewTag = async (inputData) => {
  try {
    if (inputData.name) {
      const tagName = inputData.name;
      let response = await searchTagTable(tagName);

      if (response.length >= 1) {
        return {
          status: 400,
          data: "Tag already exist",
        };
      }
    }

    const [result] = await db.execute(createTagQuery, [
      inputData.name,
      inputData.colorCode,
      inputData.status,
    ]);
    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Data Insertion Failed",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const searchTagTable = async (tagName) => {
  try {
    let [result] = await db.execute(searchTagQuery, [tagName]);

    const dataLength = result.length;

    if (dataLength == 0) {
      return {
        status: 200,
        length: dataLength,
        data: null,
        message: "Tag not found",
      };
    } else {
      return {
        status: 200,
        length: dataLength,
        data: result,
        message: "Tag found successfully",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getAllTag = async (page) => {
  try {
    let dataPerPage;
    let offset;

    if (page) {
      dataPerPage = process.env.tag_data_per_page;
      offset = (page - 1) * dataPerPage;
    } else {
      dataPerPage = 18446744073709551615;
      offset = 0;
    }

    const [countResult] = await db.execute(totalCountOfTag);
    const totalRows = countResult[0].totalRows;

    const totalPages = Math.ceil(totalRows / dataPerPage);

    const [result] = await db.execute(getAllTagQuery, [dataPerPage, offset]);

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      if (page) {
        return {
          status: 200,
          data: {
            tagList: result,
            totalPages: totalPages,
            dataPerPage: dataPerPage,
            totalRows:totalRows
          },
        };
      } else {
        return {
          status: 200,
          data: result,
        };
      }
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const deleteTagFromDb = async (tagId) => {
  try {
    const [result] = await db.execute(deleteTagQuery, ["0", tagId]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getTagFromDb = async (tagId) => {
  try {
    const [result] = await db.execute(getTagByIdQuery, [tagId]);

    if (result.length === 0) {
      return {
        status: 400,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const updateTagInDb = async (tagName, tagId, colorCode) => {
  try {
    if (tagName) {
      let response = await searchTagTable(tagName);
      
      if (response.length >= 1 && response.data[0].id != tagId) {
        return {
          status: 400,
          data: "Tag already exist",
        };
      }
    }

    const [result] = await db.execute(updateTagQuery, [tagName, colorCode, tagId]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

module.exports = {
  addNewTag,
  getAllTag,
  deleteTagFromDb,
  updateTagInDb,
  getTagFromDb,
};
