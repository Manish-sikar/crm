const {
  createCategoryQuery,
  searchCategoryTableQuery,
  getAllCategoryQuery,
  totalCountOfCategory,
  deleteCategoryQuery,
  getCategoryByIdQuery,
  updateCategoryQuery,
} = require("../Services/dbQueries");
const db = require("../../database/mySqlConnection").promise();

const createCategory = async (inputData) => {
  try {
    if (inputData.name) {
      const categoryName = inputData.name;
      let response = await searchCategoryTable(categoryName);

      if (response.length >= 1) {
        return {
          status: 400,
          data: "Category already exist",
        };
      }
    }
    const [result] = await db.execute(createCategoryQuery, [
      inputData.name,
      inputData.parent_id ?? null,
      inputData.product_id ?? null,
      inputData.status,
    ]);
    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Data Insertion Failed",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const searchCategoryTable = async (categoryName) => {
  try {
    let [result] = await db.execute(searchCategoryTableQuery, [categoryName]);
   
    const dataLength = result.length;

    if (dataLength == 0) {
      return {
        status: 200,
        length: dataLength,
        data: null,
        message: "Category not found",
      };
    } else {
      return {
        status: 200,
        length: dataLength,
        data: result,
        message: "Category found successfully",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getAllCategory = async (page) => {
  try {
    let dataPerPage;
    let offset;

    if (page) {
      dataPerPage = process.env.category_data_per_page;
      offset = (page - 1) * dataPerPage;
    } else {
      dataPerPage = 18446744073709551615;
      offset = 0;
    }

    const [countResult] = await db.execute(totalCountOfCategory);
    const totalRows = countResult[0].totalRows;

    const totalPages = Math.ceil(totalRows / dataPerPage);

    const [result] = await db.execute(getAllCategoryQuery, [
      dataPerPage,
      offset,
    ]);

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      if (page) {
        return {
          status: 200,
          data: {
            categoryList: result,
            totalPages: totalPages,
            dataPerPage: dataPerPage,
            totalRows:totalRows
          },
        };
      } else {
        return {
          status: 200,
          data: result,
        };
      }
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const deleteCategoryFromDb = async (categoryId) => {
  try {
    const [result] = await db.execute(deleteCategoryQuery, ["0", categoryId]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const updateCategoryInDb = async (categoryName, categoryId) => {
  try {
    if (categoryName) {
      let response = await searchCategoryTable(categoryName);

      if (response.length >= 1 && response.data[0].id  != categoryId) {
        return {
          status: 400,
          data: "Category already exist",
        };
      }
    }

    const [result] = await db.execute(updateCategoryQuery, [
      categoryName,
      categoryId,
    ]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getCategoryFromDb = async (categoryId) => {
  try {
    const [result] = await db.execute(getCategoryByIdQuery, [categoryId]);

    if (result.length === 0) {
      return {
        status: 400,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};



module.exports = {
  createCategory,
  getAllCategory,
  deleteCategoryFromDb,
  updateCategoryInDb,
  getCategoryFromDb,
};
