const { Console } = require("winston/lib/winston/transports");
const {
  searchCustomerByNumberQuery,
  searchCustomerByEmailQuery,
  createCustomerQuery,
  getAllCustomerQuery,
  searchCustomerQuery,
  deleteCustomerQuery,
  getCustomerByIdQuery,
  updateCustomerQuery,
  totalCountOfCustomer,
  getCustomerLocationQuery,
} = require("../Services/dbQueries");
const db = require("../../database/mySqlConnection").promise();

const createCustomer = async (inputData) => {
  try {

    if (inputData.phoneNo) {
      const phoneNumber = inputData.phoneNo;
      let response = await findCustomerByNumber(phoneNumber);

      if (response.length >= 1) {
        return {
          status: 400,
          data: response.message,
        };
      }
    }

    if (inputData.email) {
      const email = inputData.email;
      let response = await findCustomerByEmail(email);

      if (response.length >= 1) {
        return {
          status: 400,
          data: response.message,
        };
      }
    }

    const [result] = await db.execute(createCustomerQuery, [
      inputData.name || null,
      inputData.userId || 2,
     `91${inputData.phoneNo}`,
      inputData.email ?? null,
      inputData.phoneNo ,
      inputData.address || null,
      inputData.countryId || null,
      inputData.countryCode || 91,
      inputData.stateId || null,
      inputData.cityId || null,
      inputData.image || null,
      inputData.status || 1,
    ]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
        customerId: result.insertId,
      };
    } else {
      return {
        status: 400,
        data: "Data Insertion Failed",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const findCustomerByNumber = async (phoneNo) => {
  try {
    let [result] = await db.execute(searchCustomerByNumberQuery, [phoneNo]);

    const dataLength = result.length;

    // If no customer is found with the given phone number
    if (dataLength == 0) {
      return {
        status: 400,
        length: dataLength,
        data: null,
        message: "Phone Number or User does not exist",
      };
    } else {
      return {
        status: 200,
        length: dataLength,
        data: result,
        message: "Phone Number already exist",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const findCustomerByEmail = async (email) => {
  try {
    let [result] = await db.execute(searchCustomerByEmailQuery, [email]);

    const dataLength = result.length;

    if (dataLength == 0) {
      return {
        status: 200,
        length: dataLength,
        data: null,
        message: "Email does not exist",
      };
    } else {
      return {
        status: 200,
        length: dataLength,
        data: result,
        message: "Email already exist",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getCustomerList = async (page, pageSize) => {
  try {
    let dataPerPage;
    let offset;

    if (page) {
      dataPerPage = process.env.customer_data_per_page;
      offset = (page - 1) * dataPerPage;
    } else {
      dataPerPage = 18446744073709551615;
      offset = 0;
    }

    const [countResult] = await db.execute(totalCountOfCustomer);
    const totalRows = countResult[0].totalRows;

    const totalPages = Math.ceil(totalRows / dataPerPage);

    const [result] = await db.execute(getAllCustomerQuery, [
      dataPerPage,
      offset,
    ]);

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      if (page) {
        return {
          status: 200,
          data: {
            customerList: result,
            totalPages: totalPages,
            dataPerPage: dataPerPage,
            totalRows: totalRows,
          },
        };
      } else {
        return {
          status: 200,
          data: result,
        };
      }
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const deleteCustomerFromDb = async (customerId) => {
  try {
    const [result] = await db.execute(deleteCustomerQuery, ["0", customerId]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getCustomerFromDb = async (customerId) => {
  try {
    const [result] = await db.execute(getCustomerByIdQuery, [customerId]);

    if (result.length === 0) {
      return {
        status: 400,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const updateCustomerInDb = async (updatedData) => {
  try {
    if (updatedData.phoneNo) {
      const phoneNumber = updatedData.phoneNo;
      let response = await findCustomerByNumber(phoneNumber);

      if (response.length >= 1 && updatedData.id != response.data[0].id) {
        return {
          status: 400,
          data: response.message,
        };
      }
    }

    if (updatedData.email) {
      const email = updatedData.email;
      let response = await findCustomerByEmail(email);

      if (response.length >= 1 && updatedData.id != response.data[0].id) {
        return {
          status: 400,
          data: response.message,
        };
      }
    }

    const [result] = await db.execute(updateCustomerQuery, [
      updatedData.name || null,
      updatedData.employeeId || null,
      updatedData.email || null,
      updatedData.phoneNo || null,
      updatedData.address || null,
      updatedData.countryId || null,
      updatedData.stateId || null,
      updatedData.cityId || null,
      updatedData.status || null,
      updatedData.id || null,
    ]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const findCustomerLocation = async (phoneNo) => {
  try {
    let response = await findCustomerByNumber(phoneNo);
    if (response.length === 0) {
      return {
        status: 400,
        data: "User does not exist",
      };
    }

    const [result] = await db.execute(getCustomerLocationQuery, [phoneNo]);

    if (result.length === 0) {
      return {
        status: 400,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const searchCustomerFromDb = async (search) => {
  try {
    search = `%${search}%`;
    let result;

    [result] = await db.execute(searchCustomerQuery, [search, search, search]);

    if (result.length > 0) {
      return {
        status: 200,
        data: result,
      };
    }

    // If nothing is found, return an error
    return {
      status: 400,
      data: "No data found",
    };
  } catch (error) {
    throw new Error(error.message);
  }
};

module.exports = {
  createCustomer,
  getCustomerList,
  deleteCustomerFromDb,
  getCustomerFromDb,
  updateCustomerInDb,
  findCustomerByNumber,
  findCustomerLocation,
  searchCustomerFromDb,
};
