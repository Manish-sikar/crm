const {
  createCallStatusQuery,
  searchCallStatusQuery,
  getAllCallStatusQuery,
  totalCountOfCallStatus,
  deleteCallStatusQuery,
  getCallStatusByIdQuery,
  updateCallStatusQuery,
} = require("../Services/dbQueries");
const db = require("../../database/mySqlConnection").promise();

const addNewStatus = async (inputData) => {
  try {
    if (inputData.name) {
      const statusName = inputData.name;
      let response = await searchCallStatus(statusName);

      if (response.length >= 1) {
        return {
          status: 400,
          data: "Status already exist",
        };
      }
    }
    const [result] = await db.execute(createCallStatusQuery, [
      inputData.name,
      inputData.status,
    ]);
    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Data Insertion Failed",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const searchCallStatus = async (statusName) => {
  try {
    let [result] = await db.execute(searchCallStatusQuery, [statusName]);

    const dataLength = result.length;

    if (dataLength == 0) {
      return {
        status: 200,
        length: dataLength,
        data: null,
        message: "Status not found",
      };
    } else {
      return {
        status: 200,
        length: dataLength,
        data: result,
        message: "Status found successfully",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getAllStatus = async (page) => {
  try {
    let dataPerPage;
    let offset;

    if (page) {
      dataPerPage = process.env.call_status_data_per_page;
      offset = (page - 1) * dataPerPage;
    } else {
      dataPerPage = 18446744073709551615;
      offset = 0;
    }
    const [countResult] = await db.execute(totalCountOfCallStatus);
    const totalRows = countResult[0].totalRows;

    const totalPages = Math.ceil(totalRows / dataPerPage);

    const [result] = await db.execute(getAllCallStatusQuery, [
      dataPerPage,
      offset,
    ]);

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      if (page) {
        return {
          status: 200,
          data: {
            callingStatusList: result,
            totalPages: totalPages,
            dataPerPage: dataPerPage,
            totalRows:totalRows
          },
        };
      } else {
        return {
          status: 200,
          data: result,
        };
      }
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const deleteStatus = async (statusId) => {
  try {
    const [result] = await db.execute(deleteCallStatusQuery, ["0", statusId]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const updateStatus = async (statusName, statusId) => {
  try {
    if (statusName) {
      let response = await searchCallStatus(statusName);
      if (response.length >= 1) {
        return {
          status: 400,
          data: "Status already exist",
        };
      }
    }

    const [result] = await db.execute(updateCallStatusQuery, [
      statusName,
      statusId,
    ]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getStatusById = async (statusId) => {
  try {
    const [result] = await db.execute(getCallStatusByIdQuery, [statusId]);

    if (result.length === 0) {
      return {
        status: 400,
        data: "No data found",
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

module.exports = {
  addNewStatus,
  getAllStatus,
  deleteStatus,
  updateStatus,
  getStatusById,
};
