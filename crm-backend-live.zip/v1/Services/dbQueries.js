//Users
const getUserByEmailQuery = "SELECT * FROM `users` WHERE `email` = ? AND `deleted_at` IS NULL";
const getCatalogStatusQuery = "SELECT catalog_view AS catalogStatus FROM `users` WHERE `user_type` = ? AND `deleted_at` IS NULL";
const getAdminDetailsQuery = `SELECT users.name, users.email, users.phone_no As phoneNo, users.address,countries.name as country,states.name as state,cities.name as city
                              FROM    users
                              LEFT JOIN    countries ON users.country = countries.id
                              LEFT JOIN    states ON users.state = states.id
                              LEFT JOIN    cities ON users.city = cities.id
                              WHERE   users.user_type = ?`;

// Whatsapp
const storeWhatsAppMessageQuery = `INSERT INTO group_chat (group_id, receiver_no, contact_id, emp_id, message, timestamp, created_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)`;
const getAllUsersWithLatestChatQuery = `SELECT
                                              contacts.name,
                                              COALESCE(contacts.whatsapp_id, CONCAT('91', contacts.phone_no)) AS whatsappId,
                                              contacts.phone_no AS phoneNo,
                                              contacts.id,
                                              latest_message.message AS message,
                                              latest_message.emp_id AS employeeId,
                                              latest_message.latest_timestamp AS timestamp
                                        FROM
                                        contacts
                                        LEFT JOIN
                                                (
                                                    SELECT
                                                        gc.contact_id,
                                                        gc.message,
                                                        gc.emp_id,
                                                        gc.timestamp AS latest_timestamp
                                                    FROM
                                                        group_chat gc
                                                    INNER JOIN
                                                        (
                                                            SELECT
                                                                contact_id,
                                                                MAX(timestamp) AS max_timestamp
                                                            FROM
                                                                group_chat
                                                            GROUP BY
                                                                contact_id
                                                        ) latest_timestamps ON gc.contact_id = latest_timestamps.contact_id
                                                                          AND gc.timestamp = latest_timestamps.max_timestamp
                                                ) AS latest_message ON contacts.id = latest_message.contact_id
                                        ORDER BY latest_message.latest_timestamp DESC;   
                                        `
const getCustomerchatQuery = `SELECT * FROM (
                              SELECT gc.id, gc.message, gc.emp_id AS employeeId,
                                    CASE 
                                        WHEN gc.emp_id != 0 THEN u.name 
                                        ELSE c.name 
                                    END AS name,
                                    gc.timestamp
                              FROM group_chat gc
                              LEFT JOIN users u ON gc.emp_id = u.id AND gc.emp_id != 0
                              LEFT JOIN CONTACTS c ON gc.contact_id = c.id AND gc.emp_id = 0
                              WHERE gc.contact_id = ?
                              AND (gc.timestamp < ? OR ? IS NULL)
                              ORDER BY gc.timestamp DESC 
                              LIMIT ?
                            ) AS latest_records
                            ORDER BY latest_records.timestamp ASC`



                                        // Calling Sttaus
const createCallStatusQuery =  "INSERT INTO call_status (`name`,`status`, `created_at`) VALUES(?,?, CURRENT_TIMESTAMP)";
const searchCallStatusQuery =  "SELECT * FROM `call_status` WHERE `name` = ? AND `status` = 1 ";
const getAllCallStatusQuery = "SELECT id, name, status FROM `call_status` WHERE `status` = 1 LIMIT ? OFFSET ?";
const totalCountOfCallStatus = 'SELECT COUNT(*) AS totalRows FROM `call_status` WHERE `status` = 1'
const deleteCallStatusQuery = "UPDATE `call_status` SET `status` = ? WHERE `id` = ?";
const getCallStatusByIdQuery = "SELECT * FROM `call_status` WHERE `id` = ? AND `status` = 1 ";
const updateCallStatusQuery = "UPDATE `call_status` SET `name` = ? WHERE `id` = ?";

// Reason
const createReasonQuery =  "INSERT INTO reason (`name`,`status`,`created_at`) VALUES(?,?,CURRENT_TIMESTAMP)";
const searchReasonQuery =  "SELECT * FROM `reason` WHERE `name` = ? AND `status` = 1 ";
const getAllReasonQuery = "SELECT id, name, status FROM `reason` WHERE `status` = 1 LIMIT ? OFFSET ? ";
const totalCountOfReason = 'SELECT COUNT(*) AS totalRows FROM `reason` WHERE `status` = 1'
const deleteReasonQuery = "UPDATE `reason` SET `status` = ? WHERE `id` = ?";
const getReasonByIdQuery = "SELECT * FROM `reason` WHERE `id` = ? AND `status` = 1 ";
const updateReasonQuery = "UPDATE `reason` SET `name` = ? WHERE `id` = ?";


// Product
const createProductQuery =  "INSERT INTO products (`name`, `price`, `description`, `category_id`, `subcategory_id`, `status`,`created_at`) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)";
const searchProductQuery =  "SELECT * FROM `products` WHERE `name` = ? AND `status` = 1 ";
const totalCountOfProduct = 'SELECT COUNT(*) AS totalRows FROM `products` WHERE `deleted_at` IS NULL'
const deleteProductQuery = "UPDATE `products` SET `deleted_at` = CURRENT_TIMESTAMP WHERE `id` = ?";
const getProductByIdQuery = "SELECT id, name, price FROM `products` WHERE `id` = ? AND `deleted_at` IS NULL";
const getProductByNameQuery = "SELECT id, name, price FROM `products` WHERE `name` = ? AND `deleted_at` IS NULL";
// const updateProductQuery = "UPDATE `reason` SET `name` = ? WHERE `id` = ?";
const getAllProductQuery = ` SELECT 
                                  products.id, products.name, products.price, products.category_id AS categoryId,
                                  products.subcategory_id AS subCategoryId, products.status, categories.name AS categoryName, sub_categories.name AS subCategoryName
                                  FROM products
                                  LEFT JOIN 
                                          categories ON products.category_id = categories.id
                                  LEFT JOIN
                                         sub_categories ON products.subcategory_id = sub_categories.id 
                                  WHERE products.deleted_at IS NULL
                                  LIMIT ? OFFSET ? `;

const getFilterProductQuery = ` SELECT 
                                  id, name, price, category_id AS categoryId,
                                  subcategory_id AS subCategoryId, status
                                  FROM products
                                  WHERE 
                                     category_id = ? AND 
                                     subcategory_id = ? AND 
                                     deleted_at IS NULL
                                 `;

// Tag
const createTagQuery =  "INSERT INTO tag (`name`, `color_code`, `status`) VALUES(?,?,?)";
const searchTagQuery =  "SELECT * FROM `tag` WHERE `name` = ? AND `status` = 1 ";
const getAllTagQuery = "SELECT id, name, color_code AS colorCode, status FROM `tag` WHERE `status` = 1 LIMIT ? OFFSET ?";
const totalCountOfTag = 'SELECT COUNT(*) AS totalRows FROM `tag` WHERE `status` = 1'
const deleteTagQuery = "UPDATE `tag` SET `status` = ? WHERE `id` = ?";
const getTagByIdQuery = "SELECT id, name, color_code AS colorCode, status FROM `tag` WHERE `id` = ? AND `status` = 1 ";
const updateTagQuery = "UPDATE `tag` SET `name` = ? , `color_code` = ? WHERE `id` = ?";

// Customer
const createCustomerQuery =  "INSERT INTO contacts (`name`,`employee_id`, `whatsapp_id`,`email` , `phone_no`,`address`,`country`, `country_code`, `state`,`city`,`image`,`status`,`created_at`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)";
const searchCustomerByNumberQuery =  "SELECT id, name,  email, whatsapp_id AS whatsappId, phone_no AS phoneNo, address, country AS countryId, state AS stateId, city AS cityId FROM `contacts` WHERE `phone_no` = ? ";
const searchCustomerByEmailQuery =  "SELECT * FROM `contacts` WHERE `phone_no` = ? ";
const getAllCustomerQuery = "SELECT id, name,  email, phone_no AS phoneNo, address FROM `contacts` WHERE `status` = '1' LIMIT ? OFFSET ? ";
const totalCountOfCustomer = 'SELECT COUNT(*) AS totalRows FROM `contacts` WHERE `status` = 1'
const deleteCustomerQuery = "UPDATE `contacts` SET `status` = ? WHERE `id` = ?";
const updateCustomerQuery = "UPDATE `contacts` SET `name` = ?, `employee_id` = ?, `email` = ?, `phone_no` = ?, `address` = ?, `country` = ?, `state` = ?, `city` = ?, `status` = ? WHERE `id` = ?";
const getCustomerByIdQuery = "SELECT id, name,  email, phone_no AS phoneNo, address, country AS countryId, state AS stateId, city AS cityId FROM `contacts` WHERE `id` = ? AND `status` = '1' ";
const getCustomerLocationQuery = `SELECT contacts.name,contacts.phone_no As phoneNo, contacts.address,countries.name as country,states.name as state,cities.name as city
                                  FROM    contacts
                                  LEFT JOIN    countries ON contacts.country = countries.id
                                  LEFT JOIN    states ON contacts.state = states.id
                                  LEFT JOIN    cities ON contacts.city = cities.id
                                  WHERE   contacts.phone_no = ?`;
const searchCustomerQuery =  "SELECT id, name,  email, phone_no AS phoneNo, address FROM `contacts` WHERE `phone_no` LIKE  ? OR `email` LIKE  ? OR  `name` LIKE  ? AND  `status` = 1 ";                                  

// Common
const getAllCountryQuery = "SELECT `id`, `name`, `iso3` , `iso2` , `status` FROM `countries` WHERE `status` = '1' AND `id`= '101' ";
const getStateByCountryQuery = "SELECT `id`, `name`, `country_code`,  `country_id` , `iso2`  FROM `states` WHERE `country_id` = ? ";
const getCitiesByStateQuery = "SELECT `id`, `name`, `country_code`, `state_id`  FROM `cities` WHERE `state_id` = ? AND `status` = '1' ";
const getLocationIdQuery = "SELECT countries.id AS countryId, states.id AS stateId, cities.id AS cityId FROM countries LEFT JOIN states ON countries.id = states.country_id LEFT JOIN cities ON states.id = cities.state_id WHERE countries.iso2 = ?";


// Employee
const createEmployeeQuery =  "INSERT INTO users (`name`,`email`,`phone_no`,`address`,`country`,`state`,`city`,`image`,`user_type`,`status`,`employee_role`,`password`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
const searchEmployeeByNumberQuery =  "SELECT * FROM `users` WHERE `phone_no` = ? ";
const searchEmployeeByEmailQuery =  "SELECT * FROM `users` WHERE `email` = ? ";
const getAllEmployeeQuery = "SELECT id,name,email, phone_no AS phoneNo, address,image , status FROM `users` WHERE  `user_type` = '2' AND `deleted_at` IS NULL LIMIT ? OFFSET ?";
const totalCountOfEmployee = 'SELECT COUNT(*) AS totalRows FROM `users` WHERE `user_type` != 1 AND `deleted_at` IS NULL '
const getEmployeeListQuery = "SELECT id, name, email, phone_no AS phoneNo FROM `users` WHERE `user_type` != 1 ";
const searchEmployeeQuery =  "SELECT id, name,  email, phone_no AS phoneNo, address, image ,status  FROM `users` WHERE `phone_no` LIKE  ? OR `email` LIKE  ? OR  `name` LIKE  ? AND  `user_type` != 2 ";                                  


const deleteEmployeeQuery = "UPDATE `users` SET `deleted_at` = CURRENT_TIMESTAMP  WHERE `id` = ?";
const getEmployeeByIdQuery = "SELECT id, name,  email, phone_no AS phoneNo, address, image, address, country AS countryId, state AS stateId, city AS cityId FROM `users` WHERE `id` = ? AND `user_type` = '2' ";
const updateEmployeeQuery = "UPDATE `users` SET `name` = ?, `email` = ?, `phone_no` = ?, `address` = ?, `country` = ?, `state` = ?, `city` = ?, `image` = CASE WHEN ? IS NOT NULL THEN ? ELSE `image` END, `password` = CASE WHEN ? IS NOT NULL THEN ? ELSE `password` END WHERE `id` = ?";
const changeEmployeeStatusQuery = "UPDATE `users` SET `status` = CASE WHEN `status` = 0 THEN 1 ELSE 0 END WHERE `id` = ?";

// Call Logs
const addCallLogsQuery =  "INSERT INTO call_logs (`customer_id`,`employee_id`,`call_status_id`,`call_date`, `created_at`) VALUES(?,?,?,?, CURRENT_TIMESTAMP )";
const totalCountOfCallLogs = 'SELECT COUNT(*) AS totalRows FROM `call_logs` '
const getCallsPerDateQueryForAdmin = `SELECT DATE(call_date) AS callDate, COUNT(*) AS callCount 
                              FROM call_logs 
                              WHERE YEAR(call_date) = YEAR(CURRENT_DATE()) AND MONTH(call_date) = MONTH(CURRENT_DATE())
                              GROUP BY DATE(call_date);
`;

const getCallsPerDateQueryForEmployee = `SELECT DATE(call_date) AS callDate, COUNT(*) AS callCount 
                              FROM call_logs 
                              WHERE YEAR(call_date) = YEAR(CURRENT_DATE()) AND MONTH(call_date) = MONTH(CURRENT_DATE())
                              AND  employee_id = ?
                              GROUP BY DATE(call_date);
`;
const updateOnCallStatusQuery = "UPDATE `call_logs` SET  `on_call` = ? WHERE `id` = ?";
const updateCallNoteQuery = "UPDATE `call_logs` SET  `note` = ? WHERE `id` = ?";
const isCallEndedQuery = "SELECT on_call FROM call_logs WHERE id = ? ";
const addProductRelationQuery = "INSERT INTO product_relation (`lead_id`,`product_id`, `created_at`) VALUES(?,?,CURRENT_TIMESTAMP) ";
const getLatestCallLogsQuery = `
                                SELECT 
                                    call_logs.id, 
                                    call_logs.customer_id as customerId, 
                                    call_logs.call_status_id as callingStatusId, 
                                    call_logs.employee_id as employeeId, 
                                    call_logs.reason_id as reasonId, 
                                    call_logs.call_date as callDate, 
                                    call_logs.intrested as intrested, 
                                    call_logs.note, 
                                    call_logs.duration, 
                                    leads.tag_id as tagId,
                                    call_status.name As callStatus,
                                    users.name As employeeName,
                                    GROUP_CONCAT(product_relation.product_id) as productId,
                                    GROUP_CONCAT(products.name) as productName
                                FROM 
                                    contacts
                                LEFT JOIN 
                                    call_logs ON contacts.id = call_logs.customer_id 
                                LEFT JOIN 
                                    leads ON call_logs.id = leads.call_log_id
                                LEFT JOIN 
                                    users ON call_logs.employee_id = users.id
                                LEFT JOIN 
                                    call_status ON call_logs.call_status_id = call_status.id    
                                LEFT JOIN 
                                    product_relation ON leads.id = product_relation.lead_id AND product_relation.deleted_at IS NULL
                                LEFT JOIN 
                                    products ON product_relation.product_id = products.id AND products.deleted_at IS NULL
                                WHERE 
                                    contacts.phone_no = ?
                                GROUP BY 
                                    call_logs.id,
                                    customerId                                      
                                ORDER BY 
                                    call_logs.created_at DESC 
                                LIMIT ?,?`;

const getCustomerCallLogsQuery = `
                                SELECT 
                                    call_logs.id, 
                                    call_logs.customer_id as customerId, 
                                    call_logs.call_status_id as callingStatusId,                                     
                                    call_logs.call_date as callDate,                                     
                                    call_logs.note, 
                                    call_logs.duration,                                     
                                    call_status.name As callStatus,
                                    users.name As employeeName                                  
                                FROM 
                                    contacts
                                LEFT JOIN 
                                    call_logs ON contacts.id = call_logs.customer_id                                
                                LEFT JOIN 
                                    users ON call_logs.employee_id = users.id
                                LEFT JOIN 
                                    call_status ON call_logs.call_status_id = call_status.id    
                              
                                WHERE 
                                    contacts.phone_no = ?
                                GROUP BY 
                                    call_logs.id,
                                    customerId                                      
                                ORDER BY 
                                    call_logs.created_at DESC 
                                `;

const getCallLogAndCountQuery = `SELECT  
                                        cs.name AS callingStatus, 
                                        cs.id AS callingStatusId, 
                                        c.name AS customerName, 
                                        c.id AS customerId, 
                                        c.phone_no AS phoneNo, 
                                        COUNT(*) AS callCount,
                                        CASE 
                                            WHEN l.lead_status_count > 0 THEN "true"
                                            ELSE "false"
                                        END AS leadStatus
                                        FROM 
                                        call_logs cl
                                        LEFT JOIN 
                                        call_status cs ON cl.call_status_id = cs.id
                                        LEFT JOIN 
                                        contacts c ON cl.customer_id = c.id
                                        LEFT JOIN 
                                        (
                                            SELECT 
                                                customer_id,
                                                SUM(CASE WHEN lead_status = 1 THEN 1 ELSE 0 END) AS lead_status_count
                                            FROM 
                                                leads
                                            GROUP BY 
                                                customer_id
                                        ) l ON l.customer_id = c.id
                                        WHERE 
                                        cl.employee_id = ?
                                        GROUP BY                                
                                        cl.customer_id                               
                                        ORDER BY
                                        MAX(cl.created_at) DESC;
`

// Leads
const insertNewLead = "INSERT INTO leads (`unique_lead_id`,`customer_id`,`employee_id`,`call_log_id`, `tag_id`,`intrested`,`lead_date`, `schedule_date`, `lead_note`,`lead_source`,`lead_status`, `created_at`) VALUES(?,?,?,?,?,?,?,?,?,?,?, CURRENT_TIMESTAMP )"
const updateLeadStatusQuery = `UPDATE leads SET lead_status = ? WHERE id = ? AND deleted_at IS NULL`;
const selectLeadQuery = "SELECT product_id AS productId FROM product_relation WHERE lead_id = ? AND deleted_at IS NULL";
const updateLeadProductQuery = `UPDATE product_relation SET deleted_at = NOW() WHERE lead_id = ? AND product_id = ? `;
const replaceLeadProductQuery = `REPLACE INTO product_relation (lead_id, product_id, created_at) VALUES (?, ?, now())`;
const checkOpenLeadStatusQuery = `SELECT id, COUNT(*) as count FROM leads WHERE customer_id = ? AND lead_status = 1 ORDER BY created_at DESC LIMIT 1`;
const checkUniqueLeadIdQuery = `SELECT COUNT(*) as leadCount FROM leads WHERE unique_lead_id	 = ? `;
const getLeadByIdQuery = `SELECT
                               users.name AS employeeName,
                               leads.employee_id AS employeeId,
                               contacts.name AS customerName,
                               contacts.id AS customerId,
                               call_logs.note As callLogNote,
                               leads.lead_note AS leadNote,
                               leads.lead_status AS leadStatus,
                               leads.schedule_date AS scheduleCall,
                               leads.intrested,
                               tag.name AS tag,
                               tag.id AS tagId,
                               GROUP_CONCAT(DISTINCT product_relation.product_id) as productId,
                               GROUP_CONCAT(DISTINCT products.name) as productName 
                          FROM 
                               leads
                          LEFT JOIN 
                                   users ON leads.employee_id = users.id
                          LEFT JOIN 
                                   contacts ON leads.customer_id = contacts.id
                          LEFT JOIN 
                                   tag ON leads.tag_id = tag.id
                          LEFT JOIN 
                                   call_logs ON leads.call_log_id = call_logs.id
                          LEFT JOIN 
                                   product_relation ON leads.id = product_relation.lead_id AND product_relation.deleted_at IS NULL
                          LEFT JOIN 
                                   products ON product_relation.product_id = products.id  AND products.deleted_at IS NULL     
                          WHERE
                               leads.id = ? 
                          GROUP BY 
                               leads.id
                          AND
                               leads.deleted_at IS NULL `;
                               
const getCustomerLeadQuery = `SELECT 
                                    leads.id AS leadId,
                                    contacts.name AS customerName,
                                    contacts.phone_no AS phoneNo,
                                    leads.lead_note AS leadNote,
                                    users.name AS employeeName,
                                    call_logs.note As callLogNote,
                                    leads.lead_status AS leadStatus,
                                    leads.tag_id AS tagId,
                                    tag.name AS tagName,
                                    tag.color_code AS colorCode,
                                    GROUP_CONCAT(DISTINCT product_relation.product_id) as productId ,
                                    GROUP_CONCAT(DISTINCT products.name) as productName,
                                    COUNT(DISTINCT quotations.id) AS totalQuote
                              FROM 
                                leads
                              LEFT JOIN 
                                  users ON leads.employee_id = users.id
                              LEFT JOIN 
                                  contacts ON leads.customer_id = contacts.id
                              LEFT JOIN 
                                  tag ON leads.tag_id = tag.id
                              LEFT JOIN 
                                  call_logs ON leads.call_log_id = call_logs.id    
                              LEFT JOIN 
                                  product_relation ON leads.id = product_relation.lead_id AND product_relation.deleted_at IS NULL 
                              LEFT JOIN 
                                  products ON product_relation.product_id = products.id AND products.deleted_at IS NULL 
                              LEFT JOIN 
                                  quotations ON leads.id = quotations.lead_id  
                              WHERE 
                                  leads.customer_id = ? 
                              GROUP BY 
                                  leads.id
                                                                         
                              ORDER BY 
                                  (leads.lead_status = 1) DESC,
                                  (leads.lead_status = 0) DESC,
                                  (leads.lead_status = 2) DESC  `;


// Category

const createCategoryQuery = "INSERT INTO categories (`name`,`parent_id`,`product_id`,`status`,`created_at`) VALUES(?,?,?,?, CURRENT_TIMESTAMP )";
const searchCategoryTableQuery =  "SELECT * FROM `categories` WHERE `name` = ? AND `status` = 1 ";
const getAllCategoryQuery = "SELECT id, name, parent_id, product_id FROM `categories` WHERE `status` = 1 LIMIT ? OFFSET ? ";
const totalCountOfCategory = 'SELECT COUNT(*) AS totalRows FROM `categories` WHERE `status` = 1'
const deleteCategoryQuery = "UPDATE `categories` SET `status` = ? WHERE `id` = ?";
const getCategoryByIdQuery = "SELECT * FROM `categories` WHERE `id` = ? AND `status` = 1 ";
const updateCategoryQuery = "UPDATE `categories` SET `name` = ? WHERE `id` = ?";


// Sub Category

const createSubCategoryQuery = "INSERT INTO sub_categories (`name`,`category_id`,`status`,`created_at`) VALUES(?,?,?, CURRENT_TIMESTAMP )";
const searchSubCategoryTableQuery =  "SELECT id, name FROM `sub_categories` WHERE `name` = ? AND `deleted_at` IS NULL ";
const getAllSubCategoryQuery = "SELECT sub_categories.id, sub_categories.name, categories.name AS category, sub_categories.status FROM `sub_categories` LEFT JOIN categories ON sub_categories.category_id = categories.id  WHERE `deleted_at` IS NULL LIMIT ? OFFSET ? ";
const totalCountOfSubCategory = 'SELECT COUNT(*) AS totalRows FROM `sub_categories` WHERE `deleted_at` IS NULL'
const deleteSubCategoryQuery = "UPDATE `sub_categories` SET `deleted_at` = CURRENT_TIMESTAMP WHERE `id` = ?";
const getSubCategoryByIdQuery = "SELECT id, name, category_id AS categoryId FROM `sub_categories` WHERE `id` = ? AND `deleted_at` IS  NULL ";
const updateSubCategoryQuery = "UPDATE `sub_categories` SET `name` = ?, category_id = ? WHERE `id` = ?";
const getSubCategoryOfCategoryIdQuery = "SELECT id, name, category_id AS categoryId FROM `sub_categories` WHERE `category_id` = ? AND `deleted_at` IS  NULL ";


// Dashboard 
const getTotalCallForAdminQuery = `SELECT COUNT(*) AS totalCalls FROM call_logs WHERE DATE(call_date) = CURDATE()`;
const getTotalCallForUserQuery = `SELECT COUNT(*) AS totalCalls FROM call_logs WHERE DATE(call_date) = CURDATE() AND employee_id = ?`;

const getReceivedCallForAdminQuery = `SELECT COUNT(*) AS receivedCalls FROM call_logs WHERE DATE(call_date) = CURDATE() AND call_status_id = ?`;
const getReceivedCallForUserQuery = `SELECT COUNT(*) AS receivedCalls FROM call_logs WHERE DATE(call_date) = CURDATE()  AND call_status_id = ? AND employee_id = ?`;

const getMissedCallForAdminQuery = `SELECT COUNT(*) AS missedCalls FROM call_logs WHERE DATE(call_date) = CURDATE() AND call_status_id = ?`;
const getMissedCallForUserQuery = `SELECT COUNT(*) AS missedCalls FROM call_logs WHERE DATE(call_date) = CURDATE()  AND call_status_id = ? AND employee_id = ?`;

const avgCallDurationForAdminQuery = `SELECT AVG(TIME_TO_SEC(duration)) AS averageDurationInSeconds FROM call_logs WHERE DATE(call_date) = CURDATE()`;
const avgCallDurationForUserQuery = `SELECT AVG(TIME_TO_SEC(duration)) AS averageDurationInSeconds FROM call_logs WHERE DATE(call_date) = CURDATE() AND employee_id = ?`;

const lastActiveEmployeeQuery = `SELECT users.id, users.name, users.image, COUNT(call_logs.id) AS totalCalls, SUM(call_logs.duration) AS totalCallDurationInSeconds, SUM(call_logs.duration) / 60 AS totalCallDurationInMin FROM users JOIN call_logs ON users.id = call_logs.employee_id WHERE DATE(call_logs.call_date) = CURDATE() GROUP BY users.id HAVING COUNT(call_logs.id) > 0`;


// Quotation
const createQuotationQuery = "INSERT INTO quotations (`employee_id`, `customer_id`,`lead_id`,`total_amount`, `note`, `gst`, `quote_date`, `quote_due_date`, `created_at`) VALUES(?,?,?,?,?,?,?,?, CURRENT_TIMESTAMP )";
const addQuoteRelationQuery = "INSERT INTO quote_relations (`product_id`,`quote_id`,`price`, `custom_price`, `quantity`, `created_at`) VALUES(?,?,?,?,?, CURRENT_TIMESTAMP )";
const getQuotationDetailByIdQuery = `SELECT 
                                      quotations.total_amount AS totalAmount,
                                      quotations.gst AS gst,
                                      quotations.quote_date AS quoteDate,
                                      quotations.quote_due_date AS validUntil,
                                      contacts.name AS customerName,
                                      contacts.id AS customerId,
                                      contacts.phone_no AS customerPhoneNumber,
                                      CONCAT('[', GROUP_CONCAT(
                                        CONCAT(
                                            '{"quoteRelationId":', quote_relations.id,
                                            ',"productId":', quote_relations.product_id,
                                            ',"productName":"', products.name, '"',
                                            ',"price":', quote_relations.price,
                                            ',"quantity":', quote_relations.quantity,
                                            '}'
                                        )
                                        SEPARATOR ','
                                    ), ']') AS product
                                 FROM 
                                quotations
                                LEFT JOIN 
                                  quote_relations ON quotations.id = quote_relations.quote_id
                                LEFT JOIN 
                                  contacts ON quotations.customer_id = contacts.id
                                LEFT JOIN 
                                  products ON quote_relations.product_id = products.id
                               
                                WHERE 
                                quotations.id = ? 
                                GROUP BY 
                                quotations.id                                                              
                                `;

const getQuotationDetailByLeadQuery = `SELECT 
                                      quotations.total_amount AS totalAmount,
                                      quotations.gst AS gst,
                                      quotations.id AS quoteId,
                                      quotations.note,
                                      quotations.quote_date AS quoteDate,
                                      quotations.quote_due_date AS validUntil,
                                      contacts.name AS customerName,
                                      contacts.id AS customerId,
                                      users.name AS employeeName,
                                      users.id AS employeeId,
                                      contacts.phone_no AS customerPhoneNumber,
                                      COUNT(DISTINCT quotations.id) AS totalQuote,
                                      CONCAT('[', GROUP_CONCAT(
                                        CONCAT(
                                            '{"quoteRelationId":', quote_relations.id,
                                            ',"productId":', quote_relations.product_id,
                                            ',"productName":"', products.name, '"',
                                            ',"price":', quote_relations.price,
                                            ',"quantity":', quote_relations.quantity,
                                            '}'
                                        )
                                        SEPARATOR ','
                                    ), ']') AS product
                                 FROM 
                                quotations
                                LEFT JOIN 
                                  quote_relations ON quotations.id = quote_relations.quote_id
                                LEFT JOIN 
                                  users ON quotations.employee_id = users.id
                                LEFT JOIN 
                                  contacts ON quotations.customer_id = contacts.id
                                LEFT JOIN 
                                  products ON quote_relations.product_id = products.id
                               
                                WHERE 
                                quotations.lead_id = ? 
                                GROUP BY 
                                quotations.id,
                                quotations.employee_id
                                                              
                                `;

// Dynamic Queries

const setCallDurationQuery = ({ duration, onCall,  reasonId, callingStatusId, callLogId }) => {
  let updateClause = "";
  let queryParams = [];

  const addCondition = (columnName, value) => {
    if (value !== undefined && value !== null && (typeof value === 'string' || !isNaN(value))) {
      updateClause += updateClause.length > 0 ? " , " : " ";
      updateClause += `${columnName} = ?`;
      queryParams.push(value);
    }
  };

  addCondition('duration', duration);
  addCondition('on_call', onCall);
  addCondition('reason_id', reasonId);
  addCondition('call_status_id', callingStatusId);


  const sqlQuery = `
    UPDATE call_logs
    SET 
    updated_at = CURRENT_TIMESTAMP,
    ${updateClause}
    WHERE id = ?
  `;

  queryParams.push(callLogId);

  return { sqlQuery, queryParams };
};

const updateCallLogsQuery = ({ leadId, duration, note, reasonId, onCall, intrested, callingStatusId, callLogId }) => {
  let updateClause = "";
  let queryParams = [];

  const addCondition = (columnName, value) => {
    if (value !== undefined && value !== null && (typeof value === 'string' || !isNaN(value))) {
      updateClause += updateClause.length > 0 ? " , " : " ";
      updateClause += `${columnName} = ?`;
      queryParams.push(value);
    }
  };

  addCondition('lead_id', leadId);
  addCondition('duration', duration);
  addCondition('note', note);
  addCondition('reason_id', reasonId);
  addCondition('on_call', onCall);
  addCondition('intrested', intrested);
  addCondition('call_status_id', callingStatusId);

  const sqlQuery = `
    UPDATE call_logs
    SET 
    updated_at = CURRENT_TIMESTAMP,
    ${updateClause}
    WHERE id = ?
  `;

  queryParams.push(callLogId);

  return { sqlQuery, queryParams };
};


const updateLeadQuery = ({  note, tagId, userId, leadStatus, intrested, scheduleCall, id }) => {
  let updateClause = "";
  let queryParams = [];

  const addCondition = (columnName, value) => {
    if (value !== undefined && value !== null && (typeof value === 'string' || !isNaN(value))) {
      updateClause += updateClause.length > 0 ? " , " : " ";
      updateClause += `${columnName} = ?`;
      queryParams.push(value);
    }
  };

  addCondition('lead_note', note);
  addCondition('employee_id', userId);
  addCondition('tag_id', tagId);
  addCondition('lead_status', leadStatus);
  addCondition('intrested', intrested);
  addCondition('schedule_date', scheduleCall);


  const sqlQuery = `
    UPDATE leads
    SET 
    ${updateClause}
    WHERE id = ?
  `;

  queryParams.push(id);

  return { sqlQuery, queryParams };
};


const getCallLogsQuery = ({ employeeId, reasonId, callStatusId, categoryId, tagId, productId }, {isAdmin, userId}, pageNo) => {
  let whereClause = "";
  let limitStr = "";
  let queryParams = [];

 
    if(isAdmin){
      if (employeeId !== undefined && employeeId !== null && !isNaN(employeeId)) {
        whereClause += `WHERE call_logs.employee_id = ?`;
        queryParams.push(employeeId);
      }
    }else{
      whereClause += `WHERE call_logs.employee_id = ?`;
      queryParams.push(userId);
    }  


  if (reasonId !== undefined && reasonId !== null && !isNaN(reasonId)) {
    whereClause += whereClause.length > 0 ? " AND " : "WHERE ";
    whereClause += `call_logs.reason_id = ?`;
    queryParams.push(reasonId);
  }

  if (tagId !== undefined && tagId !== null && !isNaN(tagId)) {
    whereClause += whereClause.length > 0 ? " AND " : "WHERE ";
    whereClause += `leads.tag_id = ?`;
    queryParams.push(tagId);
  }

  if (callStatusId !== undefined && callStatusId !== null && !isNaN(callStatusId)) {
    whereClause += whereClause.length > 0 ? " AND " : "WHERE ";
    whereClause += `call_logs.call_status_id = ?`;
    queryParams.push(callStatusId);
  }

  if (productId !== undefined && productId !== null && !isNaN(productId)) {
    whereClause += whereClause.length > 0 ? " AND " : "WHERE ";
    whereClause += `product_relation.product_id = ?`;
    queryParams.push(productId);
  }

  if(pageNo !== undefined && pageNo !== null && !isNaN(pageNo)){
    const pageSize = process.env.call_logs_data_per_page
    const offset = (pageNo - 1) * pageSize;
    limitStr = `LIMIT ${offset},${pageSize}`;
    
  }

  const sqlQuery = `SELECT
                        COUNT(*) OVER() AS totalRows,  
                        contacts.id AS customerId,
                        contacts.name AS customerName,
                        contacts.phone_no AS phoneNo,
                        call_logs.id,
                        call_logs.duration,
                        call_logs.note,
                        call_logs.call_status_id AS callingStatusId,
                        call_logs.reason_id AS reasonId,
                        call_logs.call_date AS callDate, 
                        GROUP_CONCAT(DISTINCT leads.tag_id) AS tagId,
                        GROUP_CONCAT(DISTINCT product_relation.product_id) as productId, 
                        users.name AS employeeName, 
                        users.id AS employeeId,
                        call_status.name As callStatus
                      FROM 
                        call_logs 
                      LEFT JOIN 
                        users ON call_logs.employee_id = users.id
                      LEFT JOIN 
                        contacts ON call_logs.customer_id = contacts.id
                      LEFT JOIN 
                        leads ON call_logs.id = leads.call_log_id
                      LEFT JOIN 
                        call_status ON call_logs.call_status_id = call_status.id
                      LEFT JOIN 
                        product_relation ON leads.id = product_relation.lead_id AND product_relation.deleted_at IS NULL
                        ${whereClause}
                      GROUP BY 
                        customerId,
                        call_logs.id
                      ORDER BY
                        call_logs.id DESC ${limitStr}`;


  return { sqlQuery, queryParams };
};


const getLeadsQuery = ({ employeeId, categoryId, tagId, productId }, {isAdmin, userId}, pageNo) => {
  let whereClause = "";
  let limitStr = "";
  let queryParams = [];

  if(isAdmin){
    if (employeeId !== undefined && employeeId !== null && !isNaN(employeeId)) {
      whereClause += `WHERE leads.employee_id = ?`;
      queryParams.push(employeeId);
    }
  }else{
    whereClause += `WHERE leads.employee_id = ?`;
    queryParams.push(userId);
  }

  if (productId !== undefined && productId !== null && !isNaN(productId)) {
    whereClause += whereClause.length > 0 ? " AND " : "WHERE ";
    whereClause += `product_relation.product_id = ?`;
    queryParams.push(productId);
  }

  if (tagId !== undefined && tagId !== null && !isNaN(tagId)) {
    whereClause += whereClause.length > 0 ? " AND " : "WHERE ";
    whereClause += `leads.tag_id = ?`;
    queryParams.push(tagId);
  }

  // if (categoryId !== undefined && categoryId !== null && !isNaN(categoryId)) {
  //   whereClause += whereClause.length > 0 ? " AND " : "WHERE ";
  //   whereClause += `product_relation.product_id = ?`;
  //   queryParams.push(categoryId);
  // }

  if(pageNo !== undefined && pageNo !== null && !isNaN(pageNo)){
    const pageSize = process.env.leads_data_per_page
    const offset = (pageNo - 1) * pageSize;
    limitStr = `LIMIT ${offset},${pageSize}`;
    
  }

  const sqlQuery = `
                    SELECT
                          COUNT(*) OVER() AS totalCount,       
                          leads.id AS leadId,
                          contacts.name AS customerName,
                          contacts.phone_no AS phoneNo,
                          call_logs.note AS callLogNote,
                          leads.lead_note AS leadNote,
                          users.name AS employeeName,
                          leads.lead_status AS leadStatus,
                          GROUP_CONCAT(DISTINCT product_relation.product_id) as productId,
                          GROUP_CONCAT(DISTINCT products.name) as productName
                    FROM 
                         leads
                    LEFT JOIN 
                          users ON leads.employee_id = users.id
                    LEFT JOIN 
                          contacts ON leads.customer_id = contacts.id
                    LEFT JOIN 
                          call_logs ON leads.call_log_id = call_logs.id
                    LEFT JOIN 
                        product_relation ON leads.id = product_relation.lead_id AND product_relation.deleted_at IS NULL
                    LEFT JOIN 
                        products ON product_relation.product_id = products.id AND products.deleted_at IS NULL     
                        ${whereClause}
                    GROUP BY 
                        leads.id    
                    ORDER BY 
                          leads.id DESC
                          ${limitStr}`;

  return { sqlQuery, queryParams };
};



module.exports = {
  getUserByEmailQuery,
  getCatalogStatusQuery,
  getEmployeeListQuery,
  getAdminDetailsQuery,

  storeWhatsAppMessageQuery,
  getAllUsersWithLatestChatQuery,
  getCustomerchatQuery,

  createCallStatusQuery,
  searchCallStatusQuery,
  getAllCallStatusQuery,
  totalCountOfCallStatus,
  deleteCallStatusQuery,
  updateCallStatusQuery,
  getCallStatusByIdQuery,
  
  createReasonQuery,
  searchReasonQuery,
  getAllReasonQuery,
  totalCountOfReason,
  deleteReasonQuery,
  getReasonByIdQuery,
  updateReasonQuery,


  createTagQuery,
  searchTagQuery,
  getAllTagQuery,
  totalCountOfTag,
  deleteTagQuery,
  getTagByIdQuery,
  updateTagQuery,


  createCategoryQuery,
  searchCategoryTableQuery,
  getAllCategoryQuery,
  totalCountOfCategory,
  deleteCategoryQuery,
  getCategoryByIdQuery,
  updateCategoryQuery,

  createSubCategoryQuery,
  searchSubCategoryTableQuery,
  totalCountOfSubCategory,
  getAllSubCategoryQuery,
  deleteSubCategoryQuery,
  getSubCategoryByIdQuery,
  updateSubCategoryQuery,
  getSubCategoryOfCategoryIdQuery,


  getAllCountryQuery,
  getStateByCountryQuery,
  getCitiesByStateQuery,
  getLocationIdQuery,


  searchCustomerByNumberQuery,
  searchCustomerByEmailQuery,
  createCustomerQuery,
  getAllCustomerQuery,
  totalCountOfCustomer,
  searchCustomerQuery,
  deleteCustomerQuery,
  getCustomerByIdQuery,
  updateCustomerQuery,
  getCustomerLocationQuery,

  searchEmployeeByNumberQuery,
  searchEmployeeByEmailQuery,
  createEmployeeQuery,
  getAllEmployeeQuery,
  searchEmployeeQuery,
  totalCountOfEmployee,
  deleteEmployeeQuery,
  getEmployeeByIdQuery,
  updateEmployeeQuery,
  changeEmployeeStatusQuery,
  
  addCallLogsQuery,
  updateCallLogsQuery,
  isCallEndedQuery,
  addProductRelationQuery,
  getCallLogsQuery,
  totalCountOfCallLogs,
  getLatestCallLogsQuery,
  updateOnCallStatusQuery,
  setCallDurationQuery,
  getCallLogAndCountQuery,
  getCustomerCallLogsQuery,
  getCallsPerDateQueryForAdmin,
  getCallsPerDateQueryForEmployee,
  updateCallNoteQuery,


  insertNewLead,
  getLeadsQuery,
  updateLeadStatusQuery,
  getCustomerLeadQuery,
  getLeadByIdQuery,
  updateLeadQuery,
  selectLeadQuery,
  updateLeadProductQuery,
  replaceLeadProductQuery,
  checkOpenLeadStatusQuery,
  checkUniqueLeadIdQuery,

  getTotalCallForAdminQuery,
  getTotalCallForUserQuery,
  getReceivedCallForAdminQuery,
  getReceivedCallForUserQuery,
  getMissedCallForAdminQuery,
  getMissedCallForUserQuery,
  avgCallDurationForAdminQuery,
  avgCallDurationForUserQuery,
  lastActiveEmployeeQuery,



  createProductQuery,
  searchProductQuery,
  getAllProductQuery,
  totalCountOfProduct,
  deleteProductQuery,
  getFilterProductQuery,
  getProductByIdQuery,
  getProductByNameQuery,


  createQuotationQuery,
  addQuoteRelationQuery,
  getQuotationDetailByIdQuery,
  getQuotationDetailByLeadQuery


};
