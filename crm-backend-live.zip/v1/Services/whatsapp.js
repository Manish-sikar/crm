const db = require("../../database/mySqlConnection").promise();
const {
  storeWhatsAppMessageQuery,
  getAllUsersWithLatestChatQuery,
  getCustomerchatQuery,
} = require("./dbQueries");
const log = require("../../logger");

const storeWhatsAppMessage = async (chatData) => {
  try {
    // let [result] = await db.execute(storeWhatsAppMessageQuery, [
    //   chatData.senderId,
    //   chatData.receiverId ,
    //   chatData.messageId,
    //   chatData.dateTime,
    //   chatData.messageBody,
    //   chatData.messageType,
    // ]);

    let [result] = await db.execute(storeWhatsAppMessageQuery, [
      chatData.groupId,
      chatData.receiverNo,
      chatData.contactId,
      chatData.empId,
      chatData.message,
      chatData.dateTime,
    ]);

    if (result.affectedRows !== 1) {
      return {
        status: 200,
        data: null,
        message:
          "An issue occurred while attempting to store the chat in the database.",
      };
    }
    return {
      status: 200,
      data: result,
      message: "The chat was successfully stored in the database.",
    };
  } catch (error) {
    log.error({
      message: error,
      FunctionName: "storeWhatsAppMessage",
      FileName: "whatsappService",
    });
    throw new Error(error.message);
  }
};

const generateTextMessageBody = async (to, bodyText) => {
  return {
    messaging_product: "whatsapp",
    recipient_type: "individual",
    to: to,
    type: "text",
    text: {
      preview_url: false,
      body: bodyText,
    },
  };
};

const getAllUsersWithLatestChat = async (chatData) => {
  try {
    let [result] = await db.execute(getAllUsersWithLatestChatQuery);

    return {
      status: 200,
      data: result,
      message: "The chats was successfully retrieved from the database.",
    };
  } catch (error) {
    log.error({
      message: error,
      FunctionName: "getAllUsersWithLatestChat",
      FileName: "whatsappService",
    });
    throw new Error(error.message);
  }
};

const fetchCustomerChats = async (customerId, timestamp = null) => {
  try {
    let [result] = await db.execute(getCustomerchatQuery, [
      customerId,
      timestamp,
      timestamp,
      12,
    ]);

    return {
      status: 200,
      data: result,
      message:
        "The customer chats was successfully retrieved from the database.",
    };
  } catch (error) {
    log.error({
      message: error,
      FunctionName: "fetchCustomerChats",
      FileName: "whatsappService",
    });
    throw new Error(error.message);
  }
};

module.exports = {
  storeWhatsAppMessage,
  generateTextMessageBody,
  getAllUsersWithLatestChat,
  fetchCustomerChats,
};
