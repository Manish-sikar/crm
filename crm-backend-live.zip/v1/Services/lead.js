const {
  insertNewLead,
  getLeadsQuery,
  updateLeadStatusQuery,
  getCustomerLeadQuery,
  getLeadByIdQuery,
  updateLeadQuery,
  checkOpenLeadStatusQuery,
  checkUniqueLeadIdQuery,
} = require("../Services/dbQueries");
const { extractMobileNumber, getLocationId } = require("../Services/common");
const {
  addNewProduct,
  addProductRelation,
  getProductDetailsFromName,
} = require("../Services/product");
const {
  findCustomerByNumber,
  createCustomer,
} = require("../Services/customer");
const db = require("../../database/mySqlConnection").promise();
const axios = require("axios");
const log = require("../../logger");

const createNewLead = async (inputData) => {
  try {
    const [result] = await db.execute(insertNewLead, [
      inputData.queryId || null,
      inputData.customerId,
      inputData.employeeId ?? inputData.userId,
      inputData.callLogId || null,
      inputData.tagId || null,
      inputData.intrested || null,
      inputData.leadDate || null,
      inputData.scheduleDate || null,
      inputData.leadNote || null,
      inputData.leadSource || null,
      inputData.leadStatus || 1,
    ]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: { leadId: result.insertId },
      };
    } else {
      return {
        status: 400,
        data: "Data Insertion Failed",
      };
    }
  } catch (error) {
    log.error({
      message: error,
      FunctionName: "createNewLead",
      FileName: "leadService",
    });
    throw new Error(error.message);
  }
};

const getAllLead = async (filter, User, pageNo) => {
  try {
    const { sqlQuery, queryParams } = getLeadsQuery(filter, User, pageNo);

    const [result] = await db.execute(sqlQuery, queryParams);

    const dataPerPage = process.env.leads_data_per_page;
    const totalRows = result.length > 0 ? result[0].totalCount : 0;
    const totalPages = Math.ceil(totalRows / dataPerPage);

    if (result.length === 0) {
      return {
        status: 409,
        data: "No data found",
      };
    } else {
      if (pageNo) {
        return {
          status: 200,
          data: {
            leadData: result,
            totalPages: totalPages,
            dataPerPage: dataPerPage,
          },
        };
      }

      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const changeLeadStatus = async (patchData) => {
  try {
    const { id, status } = patchData;

    const [result] = await db.execute(updateLeadStatusQuery, [status, id]);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const fetchCustomerLead = async (customerId) => {
  try {
    const [result] = await db.execute(getCustomerLeadQuery, [customerId]);

    if (result.length === 0) {
      return {
        status: 400,
        data: null,
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const getLeadFromDb = async (leadId) => {
  try {
    const [result] = await db.execute(getLeadByIdQuery, [leadId]);

    if (result.length === 0) {
      return {
        status: 200,
        data: null,
      };
    } else {
      return {
        status: 200,
        data: result,
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const updateLeadInDb = async (updatedData) => {
  try {
    const { sqlQuery, queryParams } = updateLeadQuery(updatedData);

    const [result] = await db.execute(sqlQuery, queryParams);

    if (result.affectedRows === 1) {
      return {
        status: 200,
        data: result,
      };
    } else {
      return {
        status: 400,
        data: "Some error occured during querying the database",
      };
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

const checkOpenLeadStatus = async (customerId) => {
  try {
    const [result] = await db.execute(checkOpenLeadStatusQuery, [
      customerId,
      1,
    ]);

    if (result.length === 0) {
      return {
        status: 200,
        data: { openLead: result[0].count, leadId: null },
      };
    }
    return {
      status: 200,
      data: { openLead: result[0].count, leadId: result[0].id },
    };
  } catch (error) {
    throw new Error(error.message);
  }
};

const checkUniqueLeadIdInDatabase = async (leadId) => {
  try {
    const [result] = await db.execute(checkUniqueLeadIdQuery, [leadId]);

    return result[0].leadCount > 0;
  } catch (error) {
    throw new Error(error.message);
  }
};

const fetchLeadsFromIndiaMart = async (crmKey) => {
  try {
    const response = await axios.get(
      "https://mapi.indiamart.com/wservce/crm/crmListing/v2/",
      {
        params: {
          glusr_crm_key: process.env.INDIA_MART_API_KEY,
          start_time: "13-Jan-2024",
          end_time: "20-Jan-2024",
        },
      }
    );

    // Check if the response contains data and status is OK (200)
    if (response.status === 200 && response.data) {
      // Process the fetched CRM listings data here
      // For demonstration purposes, let's assume the fetched listings are stored in a variable called listings
      const listings = response.data;

      // Return success response with fetched data
      return {
        status: 200,
        data: listings,
      };
    } else {
      // Handle the case when CRM listings are not fetched successfully
      return {
        status: 400,
        message: "Failed to fetch CRM listings from IndiaMart API",
      };
    }
  } catch (error) {
    // Handle any errors that occur during the process
    throw new Error(error.message);
  }
};

const processIndiaMartLeadsAndCustomers = async (leadArray) => {
  // const processIndiaMartLeadsAndCustomers = async () => {
  try {
    // const leadArray = [
    //   {
    //     UNIQUE_QUERY_ID: "7776395551",
    //     QUERY_TYPE: "B",
    //     QUERY_TIME: "2024-02-09 12:08:45",
    //     SENDER_NAME: "Vivek Meena",
    //     SENDER_MOBILE: "+91-6367785725",
    //     SENDER_EMAIL: "",
    //     SUBJECT: "Requirement for Milk Fat Testing Machines",
    //     SENDER_COMPANY: "",
    //     SENDER_ADDRESS: "Bundi, Rajasthan",
    //     SENDER_CITY: "Bundi",
    //     SENDER_STATE: "Rajasthan",
    //     SENDER_PINCODE: "",
    //     SENDER_COUNTRY_ISO: "IN",
    //     SENDER_MOBILE_ALT: "",
    //     SENDER_PHONE: "",
    //     SENDER_PHONE_ALT: "",
    //     SENDER_EMAIL_ALT: "",
    //     QUERY_PRODUCT_NAME: "Milk Fat Testing Machines",
    //     QUERY_MESSAGE:
    //       "My Requirement is for Milk Fat Testing Machines. Kindly send me price and other details.<br>Material : Mild Steel<br>Usage/application : Industry<br>Probable Requirement Type : Business Use<br>",
    //     QUERY_MCAT_NAME: "Milk Fat Testing Machines",
    //     CALL_DURATION: "",
    //     RECEIVER_MOBILE: "",
    //   },
    //   {
    //     UNIQUE_QUERY_ID: "7776682253",
    //     QUERY_TYPE: "B",
    //     QUERY_TIME: "2024-02-09 12:50:31",
    //     SENDER_NAME: "Mohit",
    //     SENDER_MOBILE: "+91-9359882806",
    //     SENDER_EMAIL: "mohitnakade12@gmail.com",
    //     SUBJECT: "Requirement for Milk Fat Testing Machines",
    //     SENDER_COMPANY: "",
    //     SENDER_ADDRESS: "Gondia, Maharashtra",
    //     SENDER_CITY: "Gondia",
    //     SENDER_STATE: "Maharashtra",
    //     SENDER_PINCODE: "",
    //     SENDER_COUNTRY_ISO: "IN",
    //     SENDER_MOBILE_ALT: "",
    //     SENDER_PHONE: "",
    //     SENDER_PHONE_ALT: "",
    //     SENDER_EMAIL_ALT: "",
    //     QUERY_PRODUCT_NAME: "Milk Fat Testing Machines",
    //     QUERY_MESSAGE:
    //       "I want to buy Milk Fat Testing Machines. Kindly send me price and other details.<br>Model Name/number : Imm<br>Usage/application : Laboratory Use<br>Probable Requirement Type : Business Use<br>",
    //     QUERY_MCAT_NAME: "Milk Fat Testing Machines",
    //     CALL_DURATION: "",
    //     RECEIVER_MOBILE: "",
    //   },
    // ];

    const promises = [];

    for (const lead of leadArray) {
      const productId = [];
      const isLeadDuplicate = await checkUniqueLeadIdInDatabase(
        lead.UNIQUE_QUERY_ID
      );

      if (isLeadDuplicate) {
        continue;
      }

      if (
        lead.QUERY_PRODUCT_NAME == null ||
        lead.QUERY_PRODUCT_NAME == "" ||
        lead.QUERY_PRODUCT_NAME == " "
      ) {
        continue;
      }

      const { phoneNumber, countryCode } = extractMobileNumber(
        lead.SENDER_MOBILE
      );

      if (!countryCode) {
        continue;
      }

      const existingCustomer = await findCustomerByNumber(phoneNumber);
      const existingProduct = await getProductDetailsFromName(
        lead.QUERY_PRODUCT_NAME
      );

      if (existingProduct.status == 400) {
        const result = await addNewProduct({ name: lead.QUERY_PRODUCT_NAME });
        productId.push(result.data.insertId);
      } else {
        productId.push(existingProduct.data[0].id);
      }

      if (existingCustomer.length >= 1) {
        // If customer exists, insert lead associated with the existing customer
        const customerId = existingCustomer.data[0].id;

        const promise = (async () => {
          const leadCreationResult = await createNewLead({
            queryId: lead.UNIQUE_QUERY_ID,
            customerId: customerId,
            userId: 2,
            leadNote:
              lead.QUERY_MESSAGE == ""
                ? "No note available"
                : lead.QUERY_MESSAGE,
            intrested: 1,
            tagId: 3,
            leadSource: 3,
            leadDate: lead.QUERY_TIME,
          });
          if (leadCreationResult.status == 200) {
            await addProductRelation(productId, leadCreationResult.data.leadId);
          }
        })();

        // Push the promise into the array
        promises.push(promise);
      } else {
        // If customer doesn't exist, create a new customer and insert lead
        const promise = (async () => {
          try {
            let response;
            if (lead.SENDER_COUNTRY_ISO !== null) {
              response = await getLocationId(
                lead.SENDER_COUNTRY_ISO,
                lead.SENDER_STATE,
                lead.SENDER_CITY
              );
            }

            if (response?.data?.length > 0) {
              const { countryId, stateId, cityId } = response.data[0];

              const customerCreationResult = await createCustomer({
                name: lead.SENDER_NAME,
                email: lead.SENDER_EMAIL,
                phoneNo: phoneNumber,
                address: lead.SENDER_ADDRESS,
                countryCode: countryCode,
                countryId: countryId,
                stateId: stateId,
                cityId: cityId,
              });
              if (customerCreationResult.status === 400) {
                console.error(customerCreationResult);
              }
              const leadCreationResult = await createNewLead({
                queryId: lead.UNIQUE_QUERY_ID,
                customerId: customerCreationResult.data.insertId,
                userId: 2,
                leadNote:
                  lead.QUERY_MESSAGE == ""
                    ? "No note available"
                    : lead.QUERY_MESSAGE,
                intrested: 1,
                tagId: 3,
                leadSource: 3,
                leadDate: lead.QUERY_TIME,
              });

              if (leadCreationResult.status == 200) {
                await addProductRelation(
                  productId,
                  leadCreationResult.data.leadId
                );
              } else {
                console.error(leadCreationResult);
              }
            } else {
              console.log(
                "Location data not found for lead:",
                lead.UNIQUE_QUERY_ID
              );
            }
          } catch (error) {
            console.log(lead);
            console.error(
              "Error processing lead:",
              lead.UNIQUE_QUERY_ID,
              error
            );
          }
        })();

        // Push the promise into the array
        promises.push(promise);
      }
    }

    // Await all promises concurrently
    await Promise.all(promises);
    console.log("All asynchronous operations completed successfully.");

    return {
      status: 200,
      data: "Process successfully completed",
    };
  } catch (error) {
    throw new Error(error.message);
  }
};

module.exports = {
  createNewLead,
  getAllLead,
  changeLeadStatus,
  fetchCustomerLead,
  getLeadFromDb,
  updateLeadInDb,
  checkOpenLeadStatus,
  fetchLeadsFromIndiaMart,
  processIndiaMartLeadsAndCustomers,
};
