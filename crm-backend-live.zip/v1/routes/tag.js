//tag.js
const router = require("express").Router();
const verifyRequest = require("../middlewares/loginUser");
const isAdmin = require('../middlewares/isAdmin')
const { addTag, getTagList, deleteTag, getTagById, updateTag } = require("../controllers/tagController");

// Reason route
router.post("/add-tag", verifyRequest, isAdmin, addTag);
router.get("/get-tags", verifyRequest, getTagList);
router.get("/get-tags/:page", verifyRequest, getTagList);
router.delete("/delete-tag/:id" ,verifyRequest, isAdmin, deleteTag);
router.put("/get-tag/:id", verifyRequest, isAdmin, getTagById);
router.patch("/update-tag/:id", verifyRequest, isAdmin, updateTag);

module.exports = router;
