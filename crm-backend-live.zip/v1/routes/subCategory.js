const router = require("express").Router();
const verifyRequest = require("../middlewares/loginUser");
const isAdmin = require("../middlewares/isAdmin");
const {
  addSubCategory,
  getSubCategoryList,
  deleteSubCategory,
  getSubCategoryById,
  updateSubCategory,
  getCategorySubCategory
} = require("../controllers/subCategoryController");

// Reason route
router.post("/add-subCategory", verifyRequest, isAdmin, addSubCategory);
router.get("/get-subCategory", verifyRequest, getSubCategoryList);
router.get("/get-subCategory/:page", verifyRequest, getSubCategoryList);
router.delete("/delete-subCategory/:id", verifyRequest, isAdmin, deleteSubCategory);
router.get("/get-subCategory-data/:id", verifyRequest, isAdmin, getSubCategoryById);
router.put("/update-subCategory/:id", verifyRequest, isAdmin, updateSubCategory);
router.get("/get-category-subCategory/:id", verifyRequest, isAdmin, getCategorySubCategory);

module.exports = router;
