const router = require("express").Router();
const authMiddleware = require("../middlewares/loginUser");
const { login } = require("../controllers/authController");

// POST /login route
router.post("/login", login);

module.exports = router;
