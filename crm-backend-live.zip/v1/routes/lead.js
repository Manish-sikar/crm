const router = require("express").Router();
const verifyRequest = require("../middlewares/loginUser");
const isAdmin = require("../middlewares/isAdmin");
const {
  addLead,
  getLeadList,
  updateLeadStatus,
  getCustomerLead,
  updateLead,
  getLeadById,
  fetchAndInsertIndiaMartLeads
} = require("../controllers/leadController");

// Lead route
router.post("/add-lead", verifyRequest, addLead);
router.get("/get-lead-list", verifyRequest, getLeadList);
router.get("/get-customer-lead/:id", verifyRequest, getCustomerLead);
router.patch("/update-lead-status/:id/:status", verifyRequest, updateLeadStatus);
router.patch("/update-lead/:id", verifyRequest, updateLead);
router.get("/get-lead/:id", verifyRequest, getLeadById);
router.get("/get-india-mart-lead", verifyRequest,  fetchAndInsertIndiaMartLeads);

module.exports = router;
