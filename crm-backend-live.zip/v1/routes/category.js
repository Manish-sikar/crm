const router = require("express").Router();
const verifyRequest = require("../middlewares/loginUser");
const isAdmin = require('../middlewares/isAdmin')
const { addCategory, getCategoryList, deleteCategory, getCategoryById, updateCategory} = require("../controllers/categoryController");

// Category route
router.post("/add-category", verifyRequest, isAdmin, addCategory);
router.get("/get-category", verifyRequest, getCategoryList);
router.get("/get-category/:page", verifyRequest, getCategoryList);
router.delete("/delete-category/:id" ,verifyRequest, isAdmin, deleteCategory);
router.put("/get-category/:id", verifyRequest, isAdmin, getCategoryById);
router.put("/update-category/:id", verifyRequest, isAdmin, updateCategory);

module.exports = router;
