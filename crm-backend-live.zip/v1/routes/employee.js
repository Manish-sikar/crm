//Employee.js
const router = require("express").Router();
const multer = require("multer");

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, constants.IMG_DIR_PATH); // Specify the directory for file storage
  },
  filename: (req, file, cb) => {
    // Generate a unique filename using a timestamp and the original file name
    const uniqueFilename = Date.now() + "-" + file.originalname;
    req.fileName = uniqueFilename;
    cb(null, uniqueFilename);
  },
});
const upload = multer({ storage: storage });
const verifyRequest = require("../middlewares/loginUser");
const isAdmin = require('../middlewares/isAdmin')
const {
  addEmployee,
  getAllEmployee,
  deleteEmployee,
  getEmployeeById,
  updateEmployee,
  changeEmployeeStatus,
  getEmployeeData,
  searchEmployeeByDetails
} = require("../controllers/employeeController");

// Middleware to remove the uploaded file if an error occurs
const removeFileOnError = (req, res, next) => {
  const removeFile = () => {
    if (req.file) {
      const filePath = path.join(__dirname, "..", "uploads", req.file.filename);
      fs.unlink(filePath, (err) => {
        if (err) {
          console.error("Error removing uploaded file:", err);
        }
      });
    }
  };

  // Override the res.end method to remove the file in case of an error
  const originalEnd = res.end;
  res.end = function (chunk, encoding) {
    originalEnd.apply(this, arguments);
    const statusCode = this.statusCode || 200;
    if (statusCode >= 400) {
      removeFile();
    }
  };

  // Call the next middleware or route handler
  next();
};

// Employee route
router.post(
  "/add-employee",
  verifyRequest,
  upload.single("image"),
  addEmployee
);
router.get("/get-all-employee/:page", verifyRequest, isAdmin, getAllEmployee);
router.get("/search-employee/:search", verifyRequest, searchEmployeeByDetails);
router.delete("/delete-employee/:id", verifyRequest, isAdmin, deleteEmployee);
router.put("/get-employee/:id", verifyRequest, isAdmin, getEmployeeById);
router.put(
  "/update-employee/:id",
  verifyRequest,
  isAdmin,
  upload.single("image"),
  updateEmployee
);
router.put("/change-employee-status/:id", verifyRequest, isAdmin, changeEmployeeStatus);
router.get("/get-employee-list", verifyRequest, getEmployeeData);

module.exports = router;
