const router = require("express").Router();
const verifyRequest = require("../middlewares/loginUser");
const isAdmin = require("../middlewares/isAdmin");
const {
  verifyWhatsappWebhook,
  handleWhatsappResponse,
  sendWhatsappMessage,
  getChatsList,
  getCustomerChats
} = require("../controllers/whatsappController");

// Whatsapp route
router.get("/whatsapp/webhook", verifyWhatsappWebhook);
router.post("/whatsapp/webhook", handleWhatsappResponse);
router.post("/whatsapp/sendMessage", verifyRequest, sendWhatsappMessage);
router.get("/whatsapp/chats",verifyRequest, getChatsList);
router.get("/whatsapp/chats/:id",verifyRequest, getCustomerChats);

module.exports = router;
