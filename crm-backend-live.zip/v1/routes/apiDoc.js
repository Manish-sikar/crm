// const router = require("express").Router();
// const swaggerUi = require('swagger-ui-express');
// const swaggerDocument = require('../apiDoc.json');

// // // Api Doc Route
// router.use('/api-docs', swaggerUi.serve);
// router.get('/api-docs', swaggerUi.setup(swaggerDocument));

// module.exports = router;
