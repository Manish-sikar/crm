//Quotation.js
const router = require("express").Router();
const verifyRequest = require("../middlewares/loginUser");
const isAdmin = require("../middlewares/isAdmin");
const {
    addQuotation,
    generateQuotationPdf,
    getLeadQuotation
} = require("../controllers/quotationController");
const { getQuotationDetail } = require("../Services/quotation");

// Quotation route
router.post("/add-quotation", verifyRequest, addQuotation);
router.get("/generate-pdf/:id",  generateQuotationPdf);
router.get("/get-lead-quotation/:id",  getLeadQuotation);
// router.post("/update-call", verifyRequest, updateCall);
// router.put("/update-call-duration", verifyRequest, updateCallDuration);
// router.put("/user-on-call/:id", verifyRequest, userOnCall);
// router.get("/get-call-logs", verifyRequest, getCallLog);
// router.get("/call-logs", verifyRequest, getCallLogsAndCount);
// router.get("/customer-call-logs/:phoneNo", verifyRequest, getCustomerCallLogs);

module.exports = router;
