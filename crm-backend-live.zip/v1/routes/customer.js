//customer.js
const router = require("express").Router();
const verifyRequest = require("../middlewares/loginUser");
const isAdmin = require("../middlewares/isAdmin");
const {
  addCustomer,
  getAllCustomer,
  deleteCustomer,
  getCustomerById,
  updateCustomer,
  getCustomerLocation,
  searchCustomerByDetails,
  getCustomerLeadStatus
} = require("../controllers/customerController");

// Reason route
router.post("/add-customer", verifyRequest, addCustomer);
router.get("/get-all-customer", verifyRequest, getAllCustomer);
router.get("/search-customer/:search", verifyRequest, searchCustomerByDetails);
router.delete("/delete-customer/:id", verifyRequest, deleteCustomer);
router.put("/get-customer/:id", verifyRequest, getCustomerById);
router.put("/update-customer/:id",verifyRequest,  updateCustomer);
router.get("/get-customer-location/:phoneNo", getCustomerLocation);
router.get("/get-customer-leadStatus/:id", getCustomerLeadStatus);

module.exports = router;
