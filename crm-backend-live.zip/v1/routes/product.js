const router = require("express").Router();
const verifyRequest = require("../middlewares/loginUser");
const isAdmin = require("../middlewares/isAdmin");
const {
  addProduct,
  getProductList,
  deleteProduct,
  getProductById,
  updateReason,
  getFilterProduct,
} = require("../controllers/productController");

// Product route
router.post("/add-product", verifyRequest, isAdmin, addProduct);
router.get("/get-product", verifyRequest, getProductList);
router.get("/get-product/:page", verifyRequest, getProductList);
router.delete("/delete-product/:id", verifyRequest, isAdmin, deleteProduct);
router.get("/get-product-data/:id", verifyRequest, getProductById);
router.put("/update-reason/:id", verifyRequest, isAdmin, updateReason);
router.get(
  "/get-filter-product/:categoryId/:subCategoryId",
  verifyRequest,
  getFilterProduct
);

module.exports = router;
