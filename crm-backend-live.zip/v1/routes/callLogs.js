//Call Logs.js
const router = require("express").Router();
const verifyRequest = require("../middlewares/loginUser");
const isAdmin = require("../middlewares/isAdmin");
const {
  startCall,
  updateCall,
  userOnCall,
  getCallLog,
  getCallDetails,
  updateCallDuration,
  getCallLogsAndCount,
  getCustomerCallLogs,
  getCallLogsPerDay,
  updateCallNote
} = require("../controllers/callLogsController");

// Call Log route
router.post("/start-call", verifyRequest, startCall);
router.get("/get-call-details/:phoneNo", verifyRequest, getCallDetails);
router.post("/update-call", verifyRequest, updateCall);
router.put("/update-call-duration", verifyRequest, updateCallDuration);
router.patch("/update-call-note", verifyRequest, updateCallNote);
router.put("/user-on-call/:id", verifyRequest, userOnCall);
router.get("/get-call-logs", verifyRequest, getCallLog);
router.get("/call-logs", verifyRequest, getCallLogsAndCount);
router.get("/customer-call-logs/:phoneNo", verifyRequest, getCustomerCallLogs);
router.get("/call-logs-per-day", verifyRequest, getCallLogsPerDay);

module.exports = router;
