const router = require("express").Router();
const verifyRequest = require("../middlewares/loginUser");
const isAdmin = require("../middlewares/isAdmin");
const {
  getLastActiveEmployee,
  getTotalCall,
  getReceivedCall,
  getMissedCall,
  getAvgCallDuration,
} = require("../controllers/dashboardController");

// Dashboard route
router.get("/get-last-active-employee", verifyRequest, isAdmin, getLastActiveEmployee);
router.get("/get-total-call", verifyRequest, getTotalCall);
router.get("/get-received-call", verifyRequest, getReceivedCall);
router.get("/get-missed-call", verifyRequest, getMissedCall);
router.get("/avg-call-duration", verifyRequest, getAvgCallDuration);

module.exports = router;
