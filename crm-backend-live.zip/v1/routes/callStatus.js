const router = require("express").Router();
const verifyRequest = require("../middlewares/loginUser");
const isAdmin = require('../middlewares/isAdmin')
const { addStatus, getCallStatus, deleteCallStatus, updateCallStatus, getStatusDataById } = require("../controllers/callStatusController");

// Calling Status route
router.post("/add-status", verifyRequest, isAdmin, addStatus);
router.get("/get-call-statuses/",verifyRequest,  getCallStatus);
router.get("/get-call-statuses/:page", verifyRequest,  getCallStatus);
router.delete("/delete-call-status/:id" ,verifyRequest, isAdmin, deleteCallStatus);
router.put("/get-status/:id", verifyRequest, isAdmin, getStatusDataById);
router.put("/update-status/:id", verifyRequest, isAdmin, updateCallStatus);

module.exports = router;
