const router = require("express").Router();
const verifyRequest = require("../middlewares/loginUser");
const isAdmin = require('../middlewares/isAdmin')
const { addReason, getReasonList, deleteReason, getReasonById, updateReason } = require("../controllers/reasonController");

// Reason route
router.post("/add-reason", verifyRequest, isAdmin, addReason);
router.get("/get-reason", verifyRequest,  getReasonList);
router.get("/get-reason/:page", verifyRequest,  getReasonList);
router.delete("/delete-reason/:id" ,verifyRequest, isAdmin, deleteReason);
router.put("/get-reasons/:id", verifyRequest, isAdmin, getReasonById);
router.put("/update-reason/:id", verifyRequest, isAdmin, updateReason);

module.exports = router;
