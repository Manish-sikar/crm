//customer.js
const router = require("express").Router();
const verifyRequest = require("../middlewares/loginUser");
const {  getCountryList, getStatesByCountry, getCitiesByStates} = require("../controllers/commonController");

// Common route
router.get("/get-country-list", verifyRequest, getCountryList);
router.get("/get-state-list/:id", verifyRequest, getStatesByCountry);
router.get("/get-cities-list/:id", verifyRequest, getCitiesByStates);



module.exports = router;
