const { Server } = require("socket.io");
const https = require("https");
const fs = require("fs");

let io; // Declare io variable to be accessible outside the module

const initializeSocketServer = (server) => {
  io = new Server(server);

  io.on("connection", (socket) => {
    console.log("New client connected");

    socket.on("disconnect", () => {
      console.log("Client disconnected");
    });

    socket.on("chat message", (message) => {
      console.log("Received message:", message);
      // Broadcast the message to all clients
      io.emit("chat message", message);
    });
  });

  console.log("WebSocket server is running");
};

const emitEvent = (eventName, data) => {
  if (io) {
    io.emit(eventName, data);
    console.log(`Event ${eventName} emitted`);
  } else {
    console.error("Socket.IO server is not initialized");
  }
};
console.log(process.cwd());
const startSocketServer = (socketPort = 5040) => {
  // Paths to SSL certificate and key files (replace with actual paths)
  const sslOptions = {
    key: fs.readFileSync("../ssl/keys/a0075_ae579_ce30638063beb4ae7881c485bb5d0578.key"),
    cert: fs.readFileSync("../ssl/certs/kafimoto_in_a0075_ae579_1720504414_f1e052a24353e706257413385070fe62.crt"),
   
  };


  // Create HTTPS server
  const server = https.createServer(sslOptions);

  // Initialize Socket.IO server with HTTPS server
  initializeSocketServer(server);

  // Start listening on the provided port
  server.listen(socketPort, () => {
    console.log(`Socket server listening on port ${socketPort}`);
  });
};

module.exports = {
  startSocketServer,
  emitEvent,
}