const Joi = require("joi");

const validateBody = (requestData) => {
  const Schema = Joi.object({
    name: Joi.string().min(3).required(),
    email: Joi.string().email().required(),
    phoneNo: Joi.number()
      .integer()
      .min(1000000000)
      .max(9999999999)
      .required()
      .messages({
        "number.min": "Mobile number should be 10 digit.",
        "number.max": "Mobile number should be 10 digit",
      }),
    password: Joi.string().required(),
    address: Joi.string().required(),
    countryId: Joi.number().required(),
    stateId: Joi.number().required(),
    cityId: Joi.number().required(),
    image: Joi.string().required(),
    status: Joi.number().required(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateDeleteId = (requestData) => {
  const Schema = Joi.object({
    id: Joi.string().required(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateCountryAndStateId = (requestData) => {
  const Schema = Joi.object({
    id: Joi.string().required(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateEmployeeId = (requestData) => {
  const Schema = Joi.object({
    id: Joi.string().required(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateUpdateRequest = (requestData) => {
  const Schema = Joi.object({
    id: Joi.number().required(),
    name: Joi.string().min(3).required(),
    email: Joi.string().email().required(),
    phoneNo: Joi.number()
      .integer()
      .min(1000000000)
      .max(9999999999)
      .required()
      .messages({
        "number.min": "Mobile number should be 10 digit.",
        "number.max": "Mobile number should be 10 digit",
      }),
    address: Joi.string().required(),
    password: Joi.string(),
    countryId: Joi.number().required(),
    stateId: Joi.number().required(),
    cityId: Joi.number().required(),
    image: Joi.string(),
    status: Joi.number(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

module.exports = {
  validateBody,
  validateDeleteId,
  validateCountryAndStateId,
  validateEmployeeId,
  validateUpdateRequest,
};
