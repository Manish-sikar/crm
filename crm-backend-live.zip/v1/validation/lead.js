const Joi = require("joi");

const validateBody = (requestData) => {
  const Schema = Joi.object({
    customerId: Joi.alternatives().try(Joi.string(), Joi.number()).required(),
    productId: Joi.array().items(Joi.number()).min(1),
    employeeId: Joi.alternatives().try(Joi.string(), Joi.number()),
    categoryId: Joi.alternatives().try(Joi.string(), Joi.number()),
    leadSource: Joi.number().integer(),
    leadStatus: Joi.alternatives().try(Joi.string(), Joi.number()),
    callLogId: Joi.alternatives().try(Joi.string(), Joi.number()),
    tagId: Joi.alternatives().try(Joi.string(), Joi.number()),
    scheduleDate: Joi.string().regex(/^\d{4}\/\d{2}\/\d{2} \d{2}:\d{2}$/).allow(''),
    leadDate: Joi.string()
      .required()
      .regex(/^\d{4}\/\d{2}\/\d{2} \d{2}:\d{2}:\d{2}$/),
    leadNote: Joi.string(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateLeadFilter = (requestData) => {
  const Schema = Joi.object({
    employeeId: Joi.number().integer().allow(null).allow(NaN),
    productId: Joi.number().integer().allow(null).allow(NaN),
    categoryId: Joi.number().integer().allow(null).allow(NaN),
    tagId: Joi.number().integer().allow(null).allow(NaN),
  });
  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateLeadStatus = (requestData) => {
  const Schema = Joi.object({
    id: Joi.number().integer().required(),
    status: Joi.number().integer().required(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateCustomerId = (requestData) => {
  const Schema = Joi.object({
    id: Joi.number().required(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateLeadId = (requestData) => {
  const Schema = Joi.object({
    id: Joi.number().required(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateUpdateRequest = (requestData) => {
  const Schema = Joi.object({
    id: Joi.number().required(),
    note: Joi.string().min(3).allow(""),
    productId: Joi.array().items(Joi.number()).min(0),
    intrested: Joi.string().allow(""),
    tagId: Joi.string(),
    scheduleCall: Joi.string().regex(/^\d{4}\/\d{2}\/\d{2} \d{2}:\d{2}$/).allow(''),
    leadStatus: Joi.string(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

module.exports = {
  validateBody,
  validateLeadFilter,
  validateLeadStatus,
  validateUpdateRequest,
  validateCustomerId,
  validateLeadId,
};
