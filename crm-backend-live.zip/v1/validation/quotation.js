const Joi = require("joi");

const validateBody = (requestData) => {
  const Schema = Joi.object({
    product: Joi.array()
      .items(
        Joi.object({
          productId: Joi.string().required(),
          price: Joi.string().required(),
          customPrice: Joi.string().required(),
          quantity: Joi.string().required(),
        })
      )
      .min(1)
      .required(),
    customerId: Joi.string().required(),
    note: Joi.string().allow(null).allow(""),
    leadId: Joi.string().required(),
    totalAmount: Joi.string().required(),
    gst: Joi.string().required(),
    quoteDueDate: Joi.string().isoDate().required(),
    quoteDate: Joi.string().isoDate().required(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateQuoteId = (requestData) => {
  const Schema = Joi.object({
    id: Joi.number().required(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateUpdateRequest = (requestData) => {
  const Schema = Joi.object({
    id: Joi.string().required(),
    name: Joi.string().min(3).required(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateReasonId = (requestData) => {
  const Schema = Joi.object({
    id: Joi.string().required(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

module.exports = {
  validateBody,
  validateQuoteId,
  validateUpdateRequest,
  validateReasonId,
};
