const Joi = require("joi");

const validatestartCall = (requestData) => {
  const Schema = Joi.object({
    name: Joi.string(),
    phoneNo: Joi.number()
      .integer()
      .min(1000000000)
      .max(9999999999)
      .required()
      .messages({
        "number.min": "Mobile number should be 10 digit.",
        "number.max": "Mobile number should be 10 digit",
      }),
    callingStatusId: Joi.number().integer().required(),
    callDate: Joi.string()
      .required()
      .regex(/^\d{4}\/\d{2}\/\d{2} \d{2}:\d{2}:\d{2}$/),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateEndCall = (requestData) => {
  const Schema = Joi.object({
    customerId: Joi.alternatives().try(Joi.string(), Joi.number()).required(),
    productId: Joi.array().items(Joi.number()).min(0),
    employeeId: Joi.alternatives().try(Joi.string(), Joi.number()),
    leadSource: Joi.alternatives().try(Joi.string(), Joi.number()),
    leadStatus: Joi.alternatives().try(Joi.string(), Joi.number()),
    callLogId: Joi.alternatives().try(Joi.string(), Joi.number()).required(),
    tagId: Joi.alternatives().try(Joi.string(), Joi.number()),
    duration: Joi.string().regex(/^([01]\d|2[0-3]):([0-5]\d):([0-5]\d)$/),
    note: Joi.string().allow(""),
    callingStatusId: Joi.alternatives().try(Joi.string(), Joi.number()),
    reasonId: Joi.alternatives().try(Joi.string(), Joi.number()),
    onCall: Joi.alternatives().try(Joi.string(), Joi.number()),
    scheduleDate: Joi.string()
      .regex(/^\d{4}\/\d{2}\/\d{2} \d{2}:\d{2}$/)
      .allow(""),
    callDate: Joi.string().regex(/^\d{4}\/\d{2}\/\d{2} \d{2}:\d{2}:\d{2}$/),
    intrested: Joi.alternatives().try(Joi.string(), Joi.number()),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateCallNote = (requestData) => {
  const Schema = Joi.object({
    callLogId: Joi.alternatives().try(Joi.string(), Joi.number()).required(),
    note: Joi.string().allow(""),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateCallDuration = (requestData) => {
  const Schema = Joi.object({
    employeeId: Joi.any(),
    callLogId: Joi.any().required(),
    duration: Joi.string()
      .regex(/^([01]\d|2[0-3]):([0-5]\d):([0-5]\d)$/)
      .required(),
    reasonId: Joi.any(),
    callingStatusId: Joi.any(),
    onCall: Joi.any(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateCallLog = (requestData) => {
  const Schema = Joi.object({
    employeeId: Joi.number().integer().allow(null).allow(NaN),
    categoryId: Joi.number().integer().allow(null).allow(NaN),
    productId: Joi.number().integer().allow(null).allow(NaN),
    tagId: Joi.number().integer().allow(null).allow(NaN),
    reasonId: Joi.number().integer().allow(null).allow(NaN),
    callStatusId: Joi.number().integer().allow(null).allow(NaN),
  });
  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateCallDetails = (requestData) => {
  const Schema = Joi.object({
    phoneNo: Joi.number()
      .integer()
      .min(1000000000)
      .max(9999999999)
      .required()
      .messages({
        "number.min": "Mobile number should be 10 digit.",
        "number.max": "Mobile number should be 10 digit",
      }),
    record: Joi.number().integer(),
  });
  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validateCallLogId = (requestData) => {
  const Schema = Joi.object({
    id: Joi.number().integer().required(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

const validatePhoneNumber = (requestData) => {
  const Schema = Joi.object({
    phoneNo: Joi.number().integer().required(),
  });

  const { error } = Schema.validate(requestData, {
    abortEarly: false,
    convert: false,
  });

  if (error) {
    const message = error.details.map((el) => el.message).join("\n");
    return {
      isValid: false,
      message,
    };
  }
  return { isValid: true };
};

module.exports = {
  validatestartCall,
  validateEndCall,
  validateCallLog,
  validateCallDetails,
  validateCallLogId,
  validateCallDuration,
  validatePhoneNumber,
  validateCallNote,
};
