/**
 * loginUser.js
 * @description :: middleware that verifies user's isAdmin
 */

const jwt = require("jsonwebtoken");

/**
  * @param {obj} req : request of route.
 * @param {obj} res : response of route.
 * @param {callback} next : executes the next middleware succeeding the current middleware.
 */
const isAdmin = (req, res, next) => {
    try {
      const userData = req._user;
  
      if (!userData || !userData.roles || !userData.roles.includes("ADMIN")) {
        return res.unAuthorized();
      }
  
       // If the user has ADMIN role, proceed to the next middleware
       next();
  
    } catch (error) {}
  };
module.exports = isAdmin;
