const {
  validateBody,
  validateDeleteId,
  validateUpdateRequest,
  validateProductId,
} = require("../validation/product");
const {
  addNewProduct,
  getAllProduct,
  deleteProductFromDb,
  getFilterProductList,
  getProductFromDb,
  updateReasonInDb,
} = require("../Services/product");

const addProduct = async (req, res) => {
  try {
    req.body["status"] = 1;
    let { name, status } = req.body;
    if (!name || !status) {
      return res.badRequest({
        message:
          "Insufficient request parameters! Name and Status is required.",
      });
    }
    req.body.price = parseFloat(req.body.price);
    let validateRequest = validateBody(req.body);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await addNewProduct(req.body);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      message: "Product added successfully",
      data: result.data,
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getProductList = async (req, res) => {
  try {
    const pageNo = parseInt(req.params.page);

    let result = await getAllProduct(pageNo);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Products fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};


const getFilterProduct = async (req, res) => {
  try {
    const categoryId = parseInt(req.params.categoryId);
    const subCategoryId = parseInt(req.params.subCategoryId);

    if (!categoryId || !subCategoryId) {
      return res.badRequest({
        message:
          "Insufficient request parameters! categoryId and subCategoryId is required.",
      });
    }

    let result = await getFilterProductList(categoryId, subCategoryId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Products fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const deleteProduct = async (req, res) => {
  try {
    let productId = req.params.id;

    if (!productId) {
      return res.badRequest({
        message: "Insufficient request parameters! Reason Id is required.",
      });
    }

    let validateRequest = validateDeleteId(req.params);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await deleteProductFromDb(productId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Product deleted successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getProductById = async (req, res) => {
  try {
    let productId = req.params.id;

    if (!productId) {
      return res.badRequest({
        message: "Insufficient request parameters! Status Id  is required .",
      });
    }

    let validateRequest = validateProductId({
      id: productId,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await getProductFromDb(productId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Product data fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const updateReason = async (req, res) => {
  try {
    let productId = req.params.id;
    let reasonUpdatedName = req.body.name;

    if (!productId || !reasonUpdatedName) {
      return res.badRequest({
        message:
          "Insufficient request parameters! Status Id and Name is required .",
      });
    }

    let validateRequest = validateUpdateRequest({
      id: productId,
      name: reasonUpdatedName,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await updateReasonInDb(reasonUpdatedName, productId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Reason updated successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};



module.exports = {
  addProduct,
  getProductList,
  deleteProduct,
  getProductById,
  updateReason,
  getFilterProduct,
  
};
