const {
    validateBody,
    validateDeleteId,
    validateCategoryId,
    validateUpdateRequest,
    validatesubCategoryId,
  } = require("../validation/subCategory");
  const {
    createSubCategory,
    getAllSubCategory,
    deleteSubCategoryFromDb,
    getSubCategoryFromDb,
    updateSubCategoryInDb,
    getSubCategoryOfCategory,
  } = require("../Services/subCategory");
  
  const addSubCategory = async (req, res) => {
    try {
      req.body["status"] = 1;
      let { name,  categoryId } = req.body;
      if (!name  || !categoryId) {
        return res.badRequest({
          message:
            "Insufficient request parameters! Please fill all the required field.",
        });
      }
      let validateRequest = validateBody(req.body);
  
      if (!validateRequest.isValid) {
        return res.validationError({
          message: `Invalid values in parameters, ${validateRequest.message}`,
        });
      }
  
      let result = await createSubCategory(req.body);
  
      if (result.status == 400) {
        return res.badRequest({ message: result.data });
      }
      return res.success({
        message: "Sub Category added successfully",
        data: result.data,
      });
    } catch (error) {
      return res.internalServerError({ message: error.message });
    }
  };
  
  const getSubCategoryList = async (req, res) => {
    try {
  
      const pageNo = parseInt(req.params.page);
      let result = await getAllSubCategory(pageNo);
  
      if (result.status == 400) {
        return res.badRequest({ message: result.data });
      }
      if (result.status == 409) {
        return res.recordNotFound({ message: result.data });
      }
      return res.success({
        data: result.data,
        message: "Sub Categories fetched successfully",
      });
    } catch (error) {
      return res.internalServerError({ message: error.message });
    }
  };
  
  const deleteSubCategory = async (req, res) => {
    try {
      let subCategoryId = req.params.id;
  
      if (!subCategoryId) {
        return res.badRequest({
          message: "Insufficient request parameters! Category Id is required.",
        });
      }
  
      let validateRequest = validateDeleteId(req.params);
  
      if (!validateRequest.isValid) {
        return res.validationError({
          message: `Invalid values in parameters, ${validateRequest.message}`,
        });
      }
  
      let result = await deleteSubCategoryFromDb(subCategoryId);
  
      if (result.status == 400) {
        return res.badRequest({ message: result.data });
      }
      return res.success({
        data: result.data,
        message: "Sub Category deleted successfully",
      });
    } catch (error) {
      return res.internalServerError({ message: error.message });
    }
  };
  
  const getSubCategoryById = async (req, res) => {
    try {
      let subCategoryId = req.params.id;
  
      if (!subCategoryId) {
        return res.badRequest({
          message: "Insufficient request parameters! Sub Category Id  is required .",
        });
      }
  
      let validateRequest = validatesubCategoryId({
        id: subCategoryId,
      });
  
      if (!validateRequest.isValid) {
        return res.validationError({
          message: `Invalid values in parameters, ${validateRequest.message}`,
        });
      }
  
      let result = await getSubCategoryFromDb(subCategoryId);
  
      if (result.status == 400) {
        return res.badRequest({ message: result.data });
      }
      return res.success({
        data: result.data,
        message: "Sub Category data fetched successfully",
      });
    } catch (error) {
      return res.internalServerError({ message: error.message });
    }
  };


  const getCategorySubCategory = async (req, res) => {
    try {
      let categoryId = parseInt(req.params.id);
  
      if (!categoryId) {
        return res.badRequest({
          message: "Insufficient request parameters!  Category Id  is required .",
        });
      }
  
      let validateRequest = validateCategoryId({
        id: categoryId,
      });
  
      if (!validateRequest.isValid) {
        return res.validationError({
          message: `Invalid values in parameters, ${validateRequest.message}`,
        });
      }
  
      let result = await getSubCategoryOfCategory(categoryId);
  
      if (result.status == 400) {
        return res.badRequest({ message: result.data });
      }
      return res.success({
        data: result.data,
        message: "Sub Category data fetched successfully",
      });
    } catch (error) {
      return res.internalServerError({ message: error.message });
    }
  };
  
  const updateSubCategory = async (req, res) => {
    try {
      let subCategoryId = req.params.id;
      let subCategoryUpdatedName = req.body.name;
      let categoryId = req.body.categoryId;
  
      if (!subCategoryId || !subCategoryUpdatedName) {
        return res.badRequest({
          message:
            "Insufficient request parameters! Status Id and Name is required .",
        });
      }
  
      let validateRequest = validateUpdateRequest({
        id: subCategoryId,
        categoryId: categoryId,
        name: subCategoryUpdatedName,
      });
  
      if (!validateRequest.isValid) {
        return res.validationError({
          message: `Invalid values in parameters, ${validateRequest.message}`,
        });
      }
  
      let result = await updateSubCategoryInDb(subCategoryUpdatedName, subCategoryId, categoryId);
  
      if (result.status == 400) {
        return res.badRequest({ message: result.data });
      }
      return res.success({
        data: result.data,
        message: "Sub Category updated successfully",
      });
    } catch (error) {
      return res.internalServerError({ message: error.message });
    }
  };
  
  module.exports = {
    addSubCategory,
    getSubCategoryList,
    deleteSubCategory,
    getSubCategoryById,
    updateSubCategory,
    getCategorySubCategory
  };
  