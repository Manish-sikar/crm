const {
  validateBody,
  validateDeleteId,
  validateUpdateRequest,
  validateCategoryId,
} = require("../validation/category");
const {
  createCategory,
  getAllCategory,
  deleteCategoryFromDb,
  getCategoryFromDb,
  updateCategoryInDb,
} = require("../Services/category");

const addCategory = async (req, res) => {
  try {
    req.body["status"] = 1;
    let { name, status } = req.body;
    if (!name || !status) {
      return res.badRequest({
        message:
          "Insufficient request parameters! Name and Status is required.",
      });
    }
    let validateRequest = validateBody(req.body);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await createCategory(req.body);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      message: "Category added successfully",
      data: result.data,
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getCategoryList = async (req, res) => {
  try {

    const pageNo = parseInt(req.params.page);
    let result = await getAllCategory(pageNo);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Categories fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const deleteCategory = async (req, res) => {
  try {
    let categoryId = req.params.id;

    if (!categoryId) {
      return res.badRequest({
        message: "Insufficient request parameters! Category Id is required.",
      });
    }

    let validateRequest = validateDeleteId(req.params);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await deleteCategoryFromDb(categoryId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Category deleted successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getCategoryById = async (req, res) => {
  try {
    let categoryId = req.params.id;

    if (!categoryId) {
      return res.badRequest({
        message: "Insufficient request parameters! Status Id  is required .",
      });
    }

    let validateRequest = validateCategoryId({
      id: categoryId,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await getCategoryFromDb(categoryId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Category data fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const updateCategory = async (req, res) => {
  try {
    let categoryId = req.params.id;
    let categoryUpdatedName = req.body.name;

    if (!categoryId || !categoryUpdatedName) {
      return res.badRequest({
        message:
          "Insufficient request parameters! Status Id and Name is required .",
      });
    }

    let validateRequest = validateUpdateRequest({
      id: categoryId,
      name: categoryUpdatedName,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await updateCategoryInDb(categoryUpdatedName, categoryId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Category updated successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

module.exports = {
  addCategory,
  getCategoryList,
  deleteCategory,
  getCategoryById,
  updateCategory,
};
