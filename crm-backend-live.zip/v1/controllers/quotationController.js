const {
  validateBody,
  validateQuoteId,
  validateUpdateRequest,
  validateReasonId,
} = require("../validation/quotation");
const {
  createQuotation,
  addQuoteRelation,
  createQuotationPdf,
  getQuotationDetailById,
  getQuotationDetailByLead
} = require("../Services/quotation");

const addQuotation = async (req, res) => {
  try {
    // req.body.product = JSON.parse(req.body.product.replace(/'/g, '"'));

    let validateRequest = validateBody(req.body);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }
    req.body.userId = req._user.id;

    let quoteStatus = await createQuotation(req.body);

    if (quoteStatus.status == 400) {
      return res.badRequest({ message: quoteStatus.data });
    }

    const quoteId = quoteStatus.data.insertId;

    const result = await addQuoteRelation(req.body.product, quoteId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }

    return res.success({
      message: "Quotation created successfully",
      data: result.data,
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const generateQuotationPdf = async (req, res) => {
  try {
    const quotationId = parseInt(req.params.id);

    if (!quotationId) {
      return res.badRequest({
        message: "Insufficient request parameters! Quotation Id is required.",
      });
    }

    let validateRequest = validateQuoteId({ id: quotationId });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    const { status: status, data: quotationDetails } = await getQuotationDetailById(
      quotationId
    );

    if (status == 400) {
      return res.badRequest({ message: quotationDetails });
    }

    const result = await createQuotationPdf(quotationDetails);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }

    // Send the PDF as a response
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", "attachment; filename=quotation.pdf");
    res.setHeader("Content-Length", result.pdf.length);

    res.send(result.pdf);
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getLeadQuotation = async (req, res) => {
  try {

    const leadId = parseInt(req.params.id);

    if (!leadId) {
      return res.badRequest({
        message: "Insufficient request parameters! Quotation Id is required.",
      });
    }

    let validateRequest = validateQuoteId({ id: leadId });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await getQuotationDetailByLead(leadId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 201) {
      return res.success({
        data: result.data,
        message: "No data found",
      });
    }
    return res.success({
      data: result.data,
      message: "Lead quotation fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

module.exports = {
  addQuotation,
  generateQuotationPdf,
  getLeadQuotation
};
