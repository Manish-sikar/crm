const {
  validateBody,
  validateDeleteId,
  validateUpdateRequest,
  validateCustomerId,
  validateCustomerNumber,
} = require("../validation/customer");
const {
  createCustomer,
  getCustomerList,
  deleteCustomerFromDb,
  getCustomerFromDb,
  updateCustomerInDb,
  findCustomerLocation,
  searchCustomerFromDb,
} = require("../Services/customer");
const { checkOpenLeadStatus } = require("../Services/lead");

const addCustomer = async (req, res) => {
  try {
    req.body["status"] = 1;
    let { name, email, phoneNo, cityId, stateId, countryId } = req.body;
    if (!name || !phoneNo) {
      return res.badRequest({
        message:
          "Insufficient request parameters! Name and Phone number is required.",
      });
    }

    let validateRequest = validateBody(req.body);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    req.body.userId = req._user.id; // Logged In User Id

    let result = await createCustomer(req.body);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      message: "Customer added successfully",
      data: result.data,
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getAllCustomer = async (req, res) => {
  try {
    const pageNo = parseInt(req.query.pageNo);
    const pageSize = parseInt(req.query.pageSize);

    let result = await getCustomerList(pageNo, pageSize);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Customer fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const deleteCustomer = async (req, res) => {
  try {
    let customerId = req.params.id;

    if (!customerId) {
      return res.badRequest({
        message: "Insufficient request parameters! Customer Id is required.",
      });
    }

    let validateRequest = validateDeleteId(req.params);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await deleteCustomerFromDb(customerId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Customer deleted successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getCustomerById = async (req, res) => {
  try {
    let customerId = req.params.id;

    if (!customerId) {
      return res.badRequest({
        message: "Insufficient request parameters! Status Id  is required .",
      });
    }

    let validateRequest = validateCustomerId({
      id: customerId,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await getCustomerFromDb(customerId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Customer data fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const updateCustomer = async (req, res) => {
  try {
    req.body["status"] = 1;
    let customerId = req.params.id;

    if (!customerId) {
      return res.badRequest({
        message: "Insufficient request parameters! Customer Id  is required .",
      });
    }
    req.body.id = parseInt(customerId);
    req.body.phoneNo = req.body.phoneNo.toString();
    let updatedData = req.body;
  
    let validateRequest = validateUpdateRequest(updatedData);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    req.body.phoneNo = parseInt(req.body.phoneNo);
    req.body.countryId = parseInt(req.body.countryId);
    req.body.stateId = parseInt(req.body.stateId);
    req.body.cityId = parseInt(req.body.cityId);

    updatedData.employeeId = req._user?.id;

    let updateCustomer = await updateCustomerInDb(updatedData);

    if (updateCustomer.status == 400) {
      return res.badRequest({ message: updateCustomer.data });
    }

    let result = await findCustomerLocation(req.body.phoneNo);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }

    return res.success({
      data: result.data,
      message: "Customer updated successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getCustomerLocation = async (req, res) => {
  try {
    let phoneNo = parseInt(req.params.phoneNo, 10);
    if (!phoneNo) {
      return res.badRequest({
        message: "Insufficient request parameters! Phone No. is required .",
      });
    }

    let validateRequest = validateCustomerNumber({
      phoneNo: phoneNo,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await findCustomerLocation(phoneNo);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Customer data fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const searchCustomerByDetails = async (req, res) => {
  try {
    let search = req.params.search;

    if (!search) {
      return res.badRequest({
        message: "Insufficient request parameters! Search value is required .",
      });
    }

    let result = await searchCustomerFromDb(search);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Customer data fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getCustomerLeadStatus = async (req, res) => {
  try {
    let customerId =req.params.id;
    if (!customerId) {
      return res.badRequest({
        message: "Insufficient request parameters! Customer Id is required .",
      });
    }

    let validateRequest = validateCustomerId({
      id: customerId,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await checkOpenLeadStatus(customerId);
    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Customer Open Lead fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

module.exports = {
  addCustomer,
  getAllCustomer,
  deleteCustomer,
  getCustomerById,
  updateCustomer,
  getCustomerLocation,
  searchCustomerByDetails,
  getCustomerLeadStatus,
};
