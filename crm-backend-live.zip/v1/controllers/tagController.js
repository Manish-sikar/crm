const {
  validateBody,
  validateDeleteId,
  validateUpdateRequest,
  validateTagId,
} = require("../validation/tag");
const {
  addNewTag,
  getAllTag,
  deleteTagFromDb,
  getTagFromDb,
  updateTagInDb,
} = require("../Services/tag");

const addTag = async (req, res) => {
  try {
    req.body["status"] = 1;

    let { name, status } = req.body;
    if (!name || !status) {
      return res.badRequest({
        message:
          "Insufficient request parameters! Name and Status is required.",
      });
    }

    let validateRequest = validateBody(req.body);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await addNewTag(req.body);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      message: "Tag added successfully",
      data: result.data,
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getTagList = async (req, res) => {
  try {
    const pageNo = parseInt(req.params.page);

    let result = await getAllTag(pageNo);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Tags fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const deleteTag = async (req, res) => {
  try {
    let tagId = req.params.id;

    if (!tagId) {
      return res.badRequest({
        message: "Insufficient request parameters! Status Id is required.",
      });
    }

    let validateRequest = validateDeleteId(req.params);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await deleteTagFromDb(tagId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Tag deleted successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getTagById = async (req, res) => {
  try {
    let tagId = req.params.id;

    if (!tagId) {
      return res.badRequest({
        message: "Insufficient request parameters! Status Id  is required .",
      });
    }

    let validateRequest = validateTagId({
      id: tagId,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await getTagFromDb(tagId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Tag data fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const updateTag = async (req, res) => {
  try {
    let tagId = req.params.id;
    let tagUpdatedName = req.body.name;
    let updatedColorCode = req.body.colorCode;

    if (!tagId || !tagUpdatedName) {
      return res.badRequest({
        message:
          "Insufficient request parameters! Status Id and Name is required .",
      });
    }

    let validateRequest = validateUpdateRequest({
      id: tagId,
      name: tagUpdatedName,
      colorCode: updatedColorCode,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await updateTagInDb(tagUpdatedName, tagId, updatedColorCode);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Tag updated successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

module.exports = {
  addTag,
  getTagList,
  deleteTag,
  getTagById,
  updateTag,
};
