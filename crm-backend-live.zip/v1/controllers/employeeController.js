const {
  validateBody,
  validateDeleteId,
  validateUpdateRequest,
  validateEmployeeId,
} = require("../validation/employee");
const {
  createEmployee,
  getEmployeeList,
  deleteEmployeeFromDb,
  getEmployeeFromDb,
  updateEmployeeInDb,
  updateEmployeeStatus,
  getAllEmployees,
  searchEmployeeFromDb
} = require("../Services/employee");
const { hashPassword } = require("../Services/common");

const addEmployee = async (req, res) => {
  try {
    req.body["status"] = 1;
    let {
      name,
      email,
      phoneNo,
      password,
      countryId,
      stateId,
      cityId,
      address,
    } = req.body;
    if (
      !name ||
      !phoneNo ||
      !email ||
      !password ||
      !countryId ||
      !stateId ||
      !cityId ||
      !address
    ) {
      return res.badRequest({
        message:
          "Insufficient request parameters! Please fill all the required fields.",
      });
    }
    req.body.phoneNo = parseInt(req.body.phoneNo);
    req.body.countryId = parseInt(req.body.countryId);
    req.body.stateId = parseInt(req.body.stateId);
    req.body.cityId = parseInt(req.body.cityId);
    req.body.image = req.fileName;

    let validateRequest = validateBody(req.body);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    req.body.password = await hashPassword(req.body.password); // hashing the password

    let result = await createEmployee(req.body);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      message: "Employee added successfully",
      data: result.data
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getAllEmployee = async (req, res) => {
  try {

    const pageNo = parseInt(req.params.page);

    let result = await getEmployeeList(pageNo);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Employees fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const deleteEmployee = async (req, res) => {
  try {
    let employeeId = req.params.id;

    if (!employeeId) {
      return res.badRequest({
        message: "Insufficient request parameters! Employee Id is required.",
      });
    }

    let validateRequest = validateDeleteId(req.params);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await deleteEmployeeFromDb(employeeId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Employee deleted successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getEmployeeById = async (req, res) => {
  try {
    let employeeId = req.params.id;

    if (!employeeId) {
      return res.badRequest({
        message: "Insufficient request parameters! Employee Id  is required .",
      });
    }

    let validateRequest = validateEmployeeId({
      id: employeeId,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await getEmployeeFromDb(employeeId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Employee data fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const updateEmployee = async (req, res) => {
  try {
    let employeeId = req.params.id;
    let updatedData = req.body;

if (!employeeId || isNaN(employeeId)) {
      return res.badRequest({
        message: "Insufficient request parameters! Employee Id  is required .",
      });
    }

    req.body.id = parseInt(req.body.id);
    req.body.phoneNo = parseInt(req.body.phoneNo);
    req.body.countryId = parseInt(req.body.countryId);
    req.body.stateId = parseInt(req.body.stateId);
    req.body.cityId = parseInt(req.body.cityId);
    req.body.image = req.fileName;

    let validateRequest = validateUpdateRequest(updatedData);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }
    if(req.body.password){
      req.body.password = await hashPassword(req.body.password); // hashing the password
    }

    let result = await updateEmployeeInDb(updatedData);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Customer updated successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const changeEmployeeStatus = async (req, res) => {
  try {
    let employeeId = req.params.id;

    if (!employeeId) {
      return res.badRequest({
        message: "Insufficient request parameters! Employee Id  is required .",
      });
    }

    let validateRequest = validateEmployeeId({
      id: employeeId,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await updateEmployeeStatus(employeeId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Employee status changed successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getEmployeeData = async (req, res) => {
  try {
    let result = await getAllEmployees();

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Employee list fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const searchEmployeeByDetails = async (req, res) => {
  try {
    let search = req.params.search;

    if (!search) {
      return res.badRequest({
        message: "Insufficient request parameters! Search value is required .",
      });
    }

    let result = await searchEmployeeFromDb(search);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Employee data fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

module.exports = {
  addEmployee,
  getAllEmployee,
  deleteEmployee,
  getEmployeeById,
  updateEmployee,
  changeEmployeeStatus,
  getEmployeeData,
  searchEmployeeByDetails
};
