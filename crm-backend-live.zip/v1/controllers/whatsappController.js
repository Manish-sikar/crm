const axios = require("axios");
const { totalCall } = require("../Services/dashboard");
const log = require("../../logger");
const {
  findCustomerByNumber,
  createCustomer,
} = require("../Services/customer");
const {
  storeWhatsAppMessage,
  generateTextMessageBody,
  getAllUsersWithLatestChat,
  fetchCustomerChats,
} = require("../Services/whatsapp");
const { validateUniqueId } = require("../validation/common");
const moment = require("moment");
const { emitEvent } = require("../socket/socketServer");
const { v4: uuidv4 } = require("uuid");

const whatsappApiUrl = `https://graph.facebook.com/${process.env.Version}/${process.env.PhoneNumberID}/messages`;

const verifyWhatsappWebhook = async (req, res) => {
  try {
    const {
      "hub.mode": mode,
      "hub.challenge": challenge,
      "hub.verify_token": token,
    } = req.query;

    const myToken = "node";

    if (mode && token) {
      if (mode === "subscribe" && token === myToken) {
        return res.status(200).send(challenge);
      } else {
        return res.status(403).send("Invalid token or mode");
      }
    } else {
      return res.status(400).send("Missing required parameters");
    }
  } catch (error) {
    log.error({
      message: error.message,
      FunctionName: "verifyWhatsappWebhook",
      FileName: "whatsappController",
    });
    return res.status(500).send({ message: "Internal Server Error" });
  }
};

const handleWhatsappResponse = async (req, res) => {
  try {
    const bodyParam = req.body;
    // console.log(JSON.stringify(bodyParam, null, 2));
    const whatsappObj = bodyParam.entry[0].changes[0].value;

    if (whatsappObj.messages) {
      const { contacts, messages } = whatsappObj;
      const result = await processMessage(contacts[0], messages[0]);

      if (!result) {
        return res.status(400);
      }
    }

    emitEvent("newMessage", { message: "New message received" });

    return res.status(200).send("success"); // Sends "Success" with status code 200
  } catch (error) {
    log.error({
      message: error.message,
      FunctionName: "handleWhatsappResponse",
      FileName: "whatsappController",
    });
    return res.status(500).send({ message: "Internal Server Error" });
  }
};

const processMessage = async (contacts, messages) => {
  try {
    const customerName = contacts.profile.name;
    const whatsappId = contacts.wa_id;
    let phoneNumber = whatsappId.substring(whatsappId.length - 10);
    const countryCode = whatsappId.substring(0, whatsappId.length - 10);
    let senderId;
    const isExist = await findCustomerByNumber(phoneNumber);

    if (isExist.status == 400) {
      const result = await createCustomer({
        name: customerName,
        phoneNo: phoneNumber,
        countryCode: countryCode,
        whatsappId: whatsappId,
      });

      if (result.status !== 200) {
        log.error({
          message: result.data,
          FunctionName: "processMessage",
          FileName: "whatsappController",
        });
        return false;
      }

      senderId = result.data[0].id;
    } else {
      senderId = isExist.data[0].id;
    }

    // Convert timestamp to milliseconds
    const milliseconds = parseInt(messages.timestamp) * 1000;
    const date = moment(milliseconds);

    // Format the date as per your requirement
    const formattedDate = date.format("YYYY-MM-DD HH:mm:ss");

    // const response = await storeWhatsAppMessage({
    //   senderId: senderId,
    //   receiverId: 0,
    //   messageId: messages.id,
    //   dateTime: formattedDate,
    //   messageBody: messages.text.body,
    //   messageType: messages.type,
    // });

    const response = await storeWhatsAppMessage({
      groupId: uuidv4(),
      receiverNo: "15550479903",
      contactId: senderId,
      empId: 0,
      message: messages.text.body,
      dateTime: formattedDate,
    });

    if (response.status == 400) {
      return false;
    }

    return true;
  } catch (error) {
    log.error({
      message: error,
      FunctionName: "processMessage",
      FileName: "whatsappController",
    });
    return res.internalServerError({ message: error.message });
  }
};

const sendWhatsappMessage = async (req, res, next) => {
  try {
    const formData = req.body;
    const empId = req._user.id;

    if (formData.type === "text") {
      const response = await sendTextMessage(formData, empId);

      if (response.status !== 200) {
        return res.badRequest({ message: response.data });
      }

      emitEvent("newMessage", { message: "New message  sent" });

      return res.success({
        data: response.data,
        message: "Chat sended successfully",
      });
    }
  } catch (error) {
    log.error({
      message: error,
      FunctionName: "processMessage",
      FileName: "whatsappController",
    });
    return res.internalServerError({ message: error.message });
  }
};

const sendTextMessage = async (formData, empId) => {
  try {
    const currentDateTime = moment().format("YYYY-MM-DD HH:mm:ss");
    const { whatsappId, body, customerId, type } = formData;
    const postBody = await generateTextMessageBody(whatsappId, body);
    const response = await whatsAppAPICall(postBody);

    if (response.status !== 200) {
      return response;
    }

    const messageId = response.data.messages[0].id;
    const result = await storeWhatsAppMessage({
      groupId: 0,
      receiverNo: whatsappId,
      contactId: customerId,
      empId: empId,
      message: body,
      dateTime: currentDateTime,
    });

    return result;
  } catch (error) {
    log.error({
      message: error,
      FunctionName: "processMessage",
      FileName: "whatsappController",
    });
  }
};

const whatsAppAPICall = async (postData) => {
  try {

    // Make a GET request to the API
    const response = await axios.post(whatsappApiUrl, postData, {
      headers: {
        Authorization: `Bearer ${process.env.Token}`,
      },
    });

    if (response.status == 200) {
      return { status: 200, data: response.data };
    }
  } catch (error) {
    console.error(error.response.data);
    log.error({
      message: error,
      FunctionName: "whatsAppAPICall",
      FileName: "whatsappController",
    });
    return { status: 400, data: error.response.data.error.message };
  }
};

const getChatsList = async (req, res) => {
  try {
    let result = await getAllUsersWithLatestChat();

    if (result.status == 400) {
      log.warn({
        message: error,
        FunctionName: "getChatsList",
        FileName: "whatsappController",
      });
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Users Chat fetched successfully",
    });
  } catch (error) {
    log.error({
      message: error,
      FunctionName: "getChatsList",
      FileName: "whatsappController",
    });
    return res.internalServerError({ message: error.message });
  }
};

const getCustomerChats = async (req, res) => {
  try {
    const { id } = req.params;
    const {timestamp} = req.query;

    if (!id) {
      log.warn({
        message: "Customer Id is required.",
        FunctionName: "getCustomerChats",
        FileName: "whatsappController",
      });
      return res.badRequest({
        message: "Insufficient request parameters! Customer Id is required.",
      });
    }
    let validateRequest = validateUniqueId(req.params);

    if (!validateRequest.isValid) {
      log.warn({
        message: validateRequest.message,
        FunctionName: "getCustomerChats",
        FileName: "whatsappController",
      });
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await fetchCustomerChats(id, timestamp);

    if (result.status == 400) {
      log.warn({
        message: error,
        FunctionName: "getCustomerChats",
        FileName: "whatsappController",
      });
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Customer Chat fetched successfully",
    });
  } catch (error) {
    log.error({
      message: error,
      FunctionName: "getCustomerChats",
      FileName: "whatsappController",
    });
    return res.internalServerError({ message: error.message });
  }
};

module.exports = {
  verifyWhatsappWebhook,
  handleWhatsappResponse,
  sendWhatsappMessage,
  getChatsList,
  getCustomerChats,
};
