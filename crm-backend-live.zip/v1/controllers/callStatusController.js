const {
  validateBody,
  validateDeleteId,
  validateUpdateRequest,
  validateCallStatusId,
} = require("../validation/callStatus");
const {
  addNewStatus,
  getAllStatus,
  deleteStatus,
  getStatusById,
  updateStatus,
} = require("../Services/callStatus");

const addStatus = async (req, res) => {
  try {
    req.body["status"] = 1;
    let { name, status } = req.body;
    if (!name || !status) {
      return res.badRequest({
        message:
          "Insufficient request parameters! Name and Status is required.",
      });
    }

    let validateRequest = validateBody(req.body);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await addNewStatus(req.body);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      message: "Calling Status add successfully",
      data: result.data,
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getCallStatus = async (req, res) => {
  try {
    const pageNo = parseInt(req.params.page);
    let result = await getAllStatus(pageNo);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Calling Statuses fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const deleteCallStatus = async (req, res) => {
  try {
   
    let statusId = req.params.id;

    if (!statusId) {
      return res.badRequest({
        message: "Insufficient request parameters! Status Id is required.",
      });
    }

    let validateRequest = validateDeleteId(req.params);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await deleteStatus(statusId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Call Status deleted successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getStatusDataById = async (req, res) => {
  try {
    let statusId = req.params.id;

    if (!statusId) {
      return res.badRequest({
        message: "Insufficient request parameters! Status Id  is required .",
      });
    }

    let validateRequest = validateCallStatusId({
      id: statusId,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await getStatusById(statusId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Calling Statuses data fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const updateCallStatus = async (req, res) => {
  try {
    let statusId = req.params.id;
    let statusUpdatedName = req.body.name;

    if (!statusId || !statusUpdatedName) {
      return res.badRequest({
        message:
          "Insufficient request parameters! Status Id and Name is required .",
      });
    }

    let validateRequest = validateUpdateRequest({
      id: statusId,
      name: statusUpdatedName,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await updateStatus(statusUpdatedName, statusId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Call Status updated successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

module.exports = {
  addStatus,
  getCallStatus,
  deleteCallStatus,
  updateCallStatus,
  getStatusDataById,
};
