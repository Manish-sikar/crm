const {
  validatestartCall,
  validateEndCall,
  validateCallLog,
  validateCallDetails,
  validateCallLogId,
  validateCallDuration,
  validatePhoneNumber,
  validateCallNote,
} = require("../validation/callLogs");
const {
  addCallLog,
  getCustomerIdForLogs,
  updateCallLog,
  checkCallStatus,
  getCallLogData,
  getCallerData,
  updateOnCallStatus,
  setCallDuration,
  getCallLogWithCount,
  getCustomerLogs,
  retrieveCallCountsByDay,
  setCallNote,
} = require("../Services/callLogs");
const { addProductRelation } = require("../Services/product");
const { findCustomerLocation } = require("../Services/customer");
const { createNewLead, checkOpenLeadStatus } = require("../Services/lead");
const log = require("../../logger");

const startCall = async (req, res) => {
  try {
    const { phoneNo } = req.body;
    const userId = req._user?.id;
    console.log(phoneNo);
    req.body.phoneNo = req.body.phoneNo.replace(/-/g, "");
    console.log(phoneNo);
    req.body.phoneNo = parseInt(req.body.phoneNo, 10);
    req.body.callingStatusId = parseInt(req.body.callingStatusId, 10);

    if (!phoneNo) {
      log.warn({
        message: "Insufficient request parameters! Phone number is required .",
        FunctionName: "startCall",
        FileName: "callLogController",
      });
      return res.badRequest({
        message: "Insufficient request parameters! Phone number is required .",
      });
    }

    const validateRequest = validatestartCall(req.body);

    if (!validateRequest.isValid) {
      log.warn({
        message: validateRequest.message,
        FunctionName: "startCall",
        FileName: "callLogController",
      });
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }
    req.body.userId = userId; // logged in User id

    let customer = await getCustomerIdForLogs(req.body);

    if (customer.status == 400) {
      return res.badRequest({ message: result.data });
    }
    req.body.employeeId = userId;
    req.body.customerId = customer.customerId;

    const customerLocation = await findCustomerLocation(phoneNo);
    const customerData = customerLocation.data[0];

    const result = await addCallLog(req.body);

    if (result.status == 400) {
      log.warn({
        message: result.data,
        FunctionName: "startCall",
        FileName: "callLogController",
      });
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: {
        callLogId: result.data.callLogId,
        customerData: { customerId: customer.customerId, ...customerData },
      },
      message: "Call Log added successfully",
    });
  } catch (error) {
    log.error({
      message: error,
      FunctionName: "startCall",
      FileName: "callLogController",
    });
    return res.internalServerError({ message: error.message });
  }
};

const updateCall = async (req, res) => {
  try {
    console.log(req.body);
    const { callLogId } = req.body;
    const userId = req._user?.id;

    if (!callLogId) {
      return res.badRequest({
        message: "Insufficient request parameters! Call Log is required .",
      });
    }

    // Convert categoryId to array of numbers
    if (req.body.productId) {
      req.body.productId = JSON.parse(req.body.productId.replace(/'/g, '"'));
    }
    req.body.intrested = req.body.intrested ?? 0;
    req.body.tagId = req.body.tagId ?? 2;
    req.body.tagId = req.body.tagId === "" ? 2 : req.body.tagId;
    req.body.duration =
      req.body.duration === "" ? "00:00:00" : req.body.duration;

    const validateRequest = validateEndCall(req.body);

    req.body.leadDate = req.body.callDate;
    req.body.intrested =
      req.body.intrested !== undefined
        ? parseInt(req.body.intrested, 10)
        : null;
    req.body.note = req.body.note !== "" ? req.body.note : null;

    if (!validateRequest.isValid) {
      log.warn({
        message: validateRequest.message,
        FunctionName: "updateCall",
        FileName: "callLogController",
      });
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }
    req.body.userId = userId; // logged in User id

    // const isCallEnded = await checkCallStatus(req.body);

    // if (!isCallEnded.status) {
    //   log.warn({
    //     message: isCallEnded.data,
    //     FunctionName: "updateCall",
    //     FileName: "callLogController",
    //   });
    //   return res.badRequest({ message: isCallEnded.data });
    // }

    const isIntrested = req.body.intrested === 1;
    if (isIntrested) {
      const leadStatus = await checkOpenLeadStatus(req.body.customerId);
      console.log(leadStatus);

      if (leadStatus.data.openLead == 0) {
        console.log(req.body);
        const addLead = await createNewLead(req.body);

        if (addLead.status == 400) {
          log.warn({
            message: addLead.data,
            FunctionName: "updateCall",
            FileName: "callLogController",
          });
          return res.badRequest({ message: addLead.data });
        }

        req.body.leadId = addLead.data.leadId;

        if (req.body.productId.length > 0) {
          const productResponse = await addProductRelation(
            req.body.productId,
            addLead.data.leadId
          );

          if (productResponse.status == 400) {
            log.warn({
              message: productResponse.data,
              FunctionName: "updateCall",
              FileName: "callLogController",
            });
            return res.badRequest({ message: productResponse.data });
          }
        }
      } else {
        req.body = leadStatus.data.leadId;
      }
    }

    let result = await updateCallLog(req.body);

    if (result.status == 400) {
      log.warn({
        message: result.data,
        FunctionName: "updateCall",
        FileName: "callLogController",
      });
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Call Log updated successfully",
    });
  } catch (error) {
    log.error({
      message: error,
      FunctionName: "updateCall",
      FileName: "callLogController",
    });
    return res.internalServerError({ message: error.message });
  }
};

const userOnCall = async (req, res) => {
  try {
    const callLogId = parseInt(req.params.id);

    const validateRequest = validateCallLogId({
      id: callLogId,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await updateOnCallStatus(callLogId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "On Call status updated successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const updateCallDuration = async (req, res) => {
  try {
    const validateRequest = validateCallDuration(req.body);

    req.body.callLogId = parseInt(req.body.callLogId, 10);
    req.body.reasonId = parseInt(req.body.reasonId, 10);
    req.body.callingStatusId = parseInt(req.body.callingStatusId, 10);
    req.body.onCall = parseInt(req.body.onCall, 10);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }
    console.log(req.body);
    let result = await setCallDuration(req.body);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "On Call status updated successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const updateCallNote = async (req, res) => {
  try {
    const validateRequest = validateCallNote(req.body);

    req.body.callLogId = parseInt(req.body.callLogId, 10);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await setCallNote(req.body);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Call Log note updated successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getCallLog = async (req, res) => {
  try {
    const formData = req.query;
    const parsedFormData = {
      employeeId: parseInt(formData.employeeId, 10),
      categoryId: parseInt(formData.categoryId, 10),
      productId: parseInt(formData.productId, 10),
      tagId: parseInt(formData.tagId, 10),
      reasonId: parseInt(formData.reasonId, 10),
      callStatusId: parseInt(formData.callStatusId, 10),
    };

    const pageNo = formData.pageNo;

    const User = {
      isAdmin: req._user.userType === 1,
      userId: req._user.id,
    };

    const validateRequest = validateCallLog(parsedFormData);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await getCallLogData(parsedFormData, User, pageNo);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Call Logs fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getCallDetails = async (req, res) => {
  try {
    req.params.phoneNo = req.params.phoneNo.replace(/-/g, "");
    const phoneNo = parseInt(req.params.phoneNo);
    const numberOfLatestRecords = req.params.number ?? 4;

    if (!phoneNo) {
      return res.badRequest({
        message: "Insufficient request parameters! Phone Number is required .",
      });
    }

    const validateRequest = validateCallDetails({
      phoneNo: phoneNo,
      record: numberOfLatestRecords,
    });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await getCallerData(phoneNo, numberOfLatestRecords);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Caller data fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getCallLogsAndCount = async (req, res) => {
  try {
    const User = {
      isAdmin: req._user.userType === 1,
      userId: req._user.id,
    };

    let result = await getCallLogWithCount(User);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Call Logs fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getCustomerCallLogs = async (req, res) => {
  try {
    const phoneNo = parseInt(req.params.phoneNo);

    if (!phoneNo) {
      return res.badRequest({
        message: "Insufficient request parameters! Phone Number is required .",
      });
    }

    const validateRequest = validatePhoneNumber({ phoneNo: phoneNo });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await getCustomerLogs(phoneNo);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Customer logs fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getCallLogsPerDay = async (req, res) => {
  try {
    const User = {
      isAdmin: req._user.userType === 1,
      userId: req._user.id,
    };

    let result = await retrieveCallCountsByDay(User);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Call logs count per day fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

module.exports = {
  startCall,
  updateCall,
  userOnCall,
  getCallLog,
  getCallDetails,
  updateCallDuration,
  getCallLogsAndCount,
  getCustomerCallLogs,
  getCallLogsPerDay,
  updateCallNote,
};
