// authController.js

const logger = require("winston");
const authService = require("../Services/auth");
const { validateLogin } = require("../validation/authValidator");

const login = async (req, res) => {
  try {
    console.log(req.body);
    let { email, password } = req.body;
    if (!email || !password) {
      return res.badRequest({
        message:
          "Insufficient request parameters! email and password is required.",
      });
    }
    

    // Trim whitespace from email and password
    email = email.trim();
    password = password.trim();

    if (email == "kai@gmail.com") {
      return res.badRequest({
        message:
          "Please utilize your own provided email address for better monitoring of your work.",
      });
    }

    let validateRequest = validateLogin({ email: email, password: password });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await authService.loginUser(email, password);
    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Login successful.",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const logout = async (req, res) => {
  try {
    return res.success({ message: "Logged Out Successfully" });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

module.exports = { login };
