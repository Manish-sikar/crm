const {
  validateBody,
  validateDeleteId,
  validateUpdateRequest,
  validateReasonId,
} = require("../validation/reason");
const {
  totalCall,
  receivedCall,
  missedCall,
  avgCallDuration,
  lastActiveEmployee
} = require("../Services/dashboard");

const getTotalCall = async (req, res) => {
  try {
    const isAdmin = req._user.userType === 1;
    const userId = req._user.id;

    let result = await totalCall(isAdmin, userId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Total Calls fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getReceivedCall = async (req, res) => {
  try {
    const isAdmin = req._user.userType === 1;
    const userId = req._user.id;

    let result = await receivedCall(isAdmin, userId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Received Calls fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getMissedCall = async (req, res) => {
  try {
    const isAdmin = req._user.userType === 1;
    const userId = req._user.id;

    let result = await missedCall(isAdmin, userId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Missed Calls fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getAvgCallDuration = async (req, res) => {
  try {
    const isAdmin = req._user.userType === 1;
    const userId = req._user.id;

    let result = await avgCallDuration(isAdmin, userId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Average Call duration fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getLastActiveEmployee = async (req, res) => {
  try {
    let result = await lastActiveEmployee();

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Last active employees list fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

module.exports = {
  getTotalCall,
  getReceivedCall,
  getMissedCall,
  getAvgCallDuration,
  getLastActiveEmployee,
};
