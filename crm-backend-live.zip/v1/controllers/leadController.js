const {
  validateBody,
  validateLeadFilter,
  validateLeadStatus,
  validateCustomerId,
  validateLeadId,
  validateUpdateRequest,
} = require("../validation/lead");
const {
  createNewLead,
  getAllLead,
  changeLeadStatus,
  fetchCustomerLead,
  getLeadFromDb,
  updateLeadInDb,
  fetchLeadsFromIndiaMart,
  processIndiaMartLeadsAndCustomers
} = require("../Services/lead");
const {
  addProductRelation,
  updateProductIdsForLead,
} = require("../Services/product");
const log = require("../../logger");

const addLead = async (req, res) => {
  try {
    if (req.body.productId) {
      req.body.productId = JSON.parse(req.body.productId.replace(/'/g, '"'));
    }

    let validateRequest = validateBody(req.body);

    if (!validateRequest.isValid) {
      log.warn({
        message: validateRequest.message,
        FunctionName: "addLead",
        FileName: "leadController",
      });
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    req.body.userId = req._user?.id; // Logged In userId

    let result = await createNewLead(req.body);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    

    const relationStatus = await addProductRelation(
      req.body.productId,
      result.data.leadId
    );

    if (relationStatus.status == 400) {
      return res.badRequest({ message: res.data });
    }

    return res.success({
      message: "Lead created successfully",
      data: result.data,
    });
  } catch (error) {
    log.error({
      message: error,
      FunctionName: "addLead",
      FileName: "leadController",
    });
    return res.internalServerError({ message: error.message });
  }
};

const getLeadList = async (req, res) => {
  try {
    const formData = req.query;
    const parsedFormData = {
      employeeId: parseInt(formData.employeeId, 10),
      productId: parseInt(formData.productId, 10),
      categoryId: parseInt(formData.categoryId, 10),
      tagId: parseInt(formData.tagId, 10),
    };

    const pageNo = parseInt(formData.pageNo, 10)

    const validateRequest = validateLeadFilter(parsedFormData);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    const User = {
      isAdmin: req._user.userType === 1,
      userId: req._user.id,
    };

    let result = await getAllLead(parsedFormData, User, pageNo);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Leads fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const getCustomerLead = async (req, res) => {
  try {
    const customerId = parseInt(req.params.id);

    if (!customerId) {
      return res.badRequest({
        message: "Insufficient request parameters! Customer Id is required.",
      });
    }

    const validateRequest = validateCustomerId({ id: customerId });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    const User = {
      isAdmin: req._user.userType === 1,
      userId: req._user.id,
    };

    let result = await fetchCustomerLead(customerId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    if (result.status == 409) {
      return res.recordNotFound({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Leads fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const updateLeadStatus = async (req, res) => {
  try {
    const leadId = parseInt(req.params.id, 10);
    const leadStatus = parseInt(req.params.status, 10);

    const patchData = {
      id: leadId,
      status: leadStatus,
    };

    if (
      leadStatus === undefined ||
      leadId === undefined ||
      leadStatus === null ||
      leadId === null
    ) {
      return res.badRequest({
        message:
          "Insufficient request parameters! Lead status and Lead Id is required.",
      });
    }

    let validateRequest = validateLeadStatus(patchData);

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await changeLeadStatus(patchData);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Lead status updated successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const updateLead = async (req, res) => {
  try {
    let leadId = parseInt(req.params.id);

    if (!leadId || isNaN(leadId)) {
      log.warn({
        message: "Insufficient request parameters! Lead Id  is required .",
        FunctionName: "updateLead",
        FileName: "leadController",
      });
      return res.badRequest({
        message: "Insufficient request parameters! Lead Id  is required .",
      });
    }
console.log(req.body)
    req.body.id = leadId;
    req.body.productId = JSON.parse(req.body.productId.replace(/'/g, '"'));

    let validateRequest = validateUpdateRequest(req.body);

    if (!validateRequest.isValid) {
      log.warn({
        message: validateRequest.message,
        FunctionName: "updateLead",
        FileName: "leadController",
      });
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }
    req.body.userId = req._user.id;
    req.body.tagId = parseInt(req.body.tagId);
    req.body.intrested = parseInt(req.body.intrested);
    req.body.leadStatus = parseInt(req.body.leadStatus);

    console.log(req.body)

    let updateResult = await updateLeadInDb(req.body);

    if (updateResult.status == 400) {
      log.warn({
        message: updateResult.data,
        FunctionName: "updateLead",
        FileName: "leadController",
      });
      return res.badRequest({ message: updateResult.data });
    }

    let result = await updateProductIdsForLead(leadId, req.body.productId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }

    return res.success({
      data: result.data,
      message: "Lead updated successfully",
    });
  } catch (error) {
    log.error({
      message: error,
      FunctionName: "updateLead",
      FileName: "leadController",
    });
    return res.internalServerError({ message: error.message });
  }
};

const getLeadById = async (req, res) => {
  try {
    let leadId = parseInt(req.params.id);

    if (!leadId || isNaN(leadId)) {
      return res.badRequest({
        message: "Insufficient request parameters! Lead Id  is required .",
      });
    }

    let validateRequest = validateLeadId({ id: leadId });

    if (!validateRequest.isValid) {
      return res.validationError({
        message: `Invalid values in parameters, ${validateRequest.message}`,
      });
    }

    let result = await getLeadFromDb(leadId);

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }
    return res.success({
      data: result.data,
      message: "Lead data fetched successfully",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

const fetchAndInsertIndiaMartLeads = async (req, res) => {
  try {
    
    let result = await fetchLeadsFromIndiaMart();

    if (result.status == 400) {
      return res.badRequest({ message: result.data });
    }

    if(result.data.TOTAL_RECORDS == 0){
      return res.success({
        data: null,
        message: result.data.MESSAGE ?? "There were no new leads found.",
      });
    }

    const response = await processIndiaMartLeadsAndCustomers(result.data.RESPONSE)
    // const response = await processIndiaMartLeadsAndCustomers()
    if (response.status == 400) {
      return res.badRequest({ message: response.data });
    }
console.log(response)
    return res.success({
      data: response.data,
      message: "Leads processed successfully.",
    });
  } catch (error) {
    return res.internalServerError({ message: error.message });
  }
};

module.exports = {
  addLead,
  getLeadList,
  updateLeadStatus,
  getCustomerLead,
  updateLead,
  getLeadById,
  fetchAndInsertIndiaMartLeads
};
